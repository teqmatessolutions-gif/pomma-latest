import React, { useState, useEffect, useCallback, memo, useMemo } from "react";
import DashboardLayout from "../layout/DashboardLayout";
import BannerMessage from "../components/BannerMessage";
import axios from "axios"; // We need axios to create the api service object
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DollarSign, BedDouble, Users, Utensils, Package, Hash, Calendar, CreditCard, X, Search, Filter, XCircle } from 'lucide-react';
import jsPDF from 'jspdf';
import { useNavigate } from "react-router-dom";
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas';
// Make sure to place your logo in the specified path or update the path accordingly.
import { useInfiniteScroll } from "./useInfiniteScroll";
import pommaLogo from '../assets/pommalogo.png';
import { formatCurrency } from '../utils/currency';
import { getApiBaseUrl } from "../utils/env";


// --- Placeholder for DashboardLayout ---
// In your actual project, you would remove this and use your own DashboardLayout component.


// --- API service ---
// Using the same API service setup as other pages
const api = axios.create({
  baseURL: getApiBaseUrl(),
});

// 1. Request Interceptor: Attaches the token to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

const resolveLoginPath = () => {
  if (typeof window === "undefined") {
    return "/admin/login";
  }
  const path = window.location.pathname || "";
  return path.startsWith("/pommaadmin") ? "/pommaadmin/login" : "/admin/login";
};

// 2. Response Interceptor: Handles 401 errors globally
api.interceptors.response.use(response => {
  return response;
}, error => {
  if (error.response && error.response.status === 401) {
    // Token is invalid or expired
    localStorage.removeItem('token');
    // Use window.location to force a full page reload to clear any stale state
    window.location.href = resolveLoginPath();
    // You could also use a state management solution to show a "Session Expired" message
  }
  return Promise.reject(error);
});


// --- Helper Components ---

const KpiCard = React.memo(({ title, value, icon, color, prefix = '', suffix = '' }) => (
  <div className="bg-white p-4 rounded-xl shadow-md flex items-center">
    <div className={`rounded-full p-3 mr-4 ${color}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm text-gray-500 font-medium">{title}</p>
      <p className="text-2xl font-bold text-gray-800">{prefix}{value}{suffix}</p>
    </div>
  </div>
));
KpiCard.displayName = 'KpiCard';

const CheckoutDetailModal = React.memo(({ checkout, onClose }) => {
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (checkout) {
      setLoading(true);
      api.get(`/bill/checkouts/${checkout.id}/details`)
        .then(response => {
          setDetails(response.data);
        })
        .catch(err => {
          console.error("Failed to load checkout details:", err);
          setDetails(null);
        })
        .finally(() => setLoading(false));
    }
  }, [checkout]);

  if (!checkout) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] p-6 relative animate-fade-in-up overflow-y-auto">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-800 z-10">
          <X size={24} />
        </button>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Checkout Details (ID: {checkout.id})</h2>

        {loading ? (
          <div className="text-center py-8">Loading details...</div>
        ) : details ? (
          <div className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Guest Name</p>
                <p className="font-semibold">{details.guest_name || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Rooms</p>
                <p className="font-semibold">{details.room_numbers?.join(', ') || details.room_number || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Checkout Date</p>
                <p className="font-semibold">{new Date(details.created_at).toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Payment Method</p>
                <p className="font-semibold">{details.payment_method || 'N/A'}</p>
              </div>
              {details.booking_id && (
                <div>
                  <p className="text-sm text-gray-500">Booking ID</p>
                  <p className="font-semibold">{details.booking_id}</p>
                </div>
              )}
              {details.package_booking_id && (
                <div>
                  <p className="text-sm text-gray-500">Package Booking ID</p>
                  <p className="font-semibold">{details.package_booking_id}</p>
                </div>
              )}
            </div>

            {/* Booking Details */}
            {details.booking_details && (
              <div className="border-t pt-4">
                <h3 className="text-lg font-semibold mb-3">Booking Information</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Check-in</p>
                    <p className="font-semibold">{details.booking_details.check_in}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Check-out</p>
                    <p className="font-semibold">{details.booking_details.check_out}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Adults</p>
                    <p className="font-semibold">{details.booking_details.adults}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Children</p>
                    <p className="font-semibold">{details.booking_details.children}</p>
                  </div>
                  {details.booking_details.package_name && (
                    <div className="col-span-2">
                      <p className="text-sm text-gray-500">Package</p>
                      <p className="font-semibold">{details.booking_details.package_name}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 3. Itemized Charges by Category */}

            {/* ROOM CHARGES SECTION */}
            {(details.room_total > 0 || details.package_total > 0) && (
              <div className="border-t pt-4">
                <h3 className="text-lg font-semibold mb-3 text-indigo-700">Room Charges</h3>
                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  {details.room_total > 0 && (
                    <div className="flex justify-between">
                      <span>Room Charges ({details.stay_nights} nights):</span>
                      <span className="font-medium">{formatCurrency(details.room_total)}</span>
                    </div>
                  )}
                  {details.package_total > 0 && (
                    <div className="flex justify-between">
                      <span>Package Charges:</span>
                      <span className="font-medium">{formatCurrency(details.package_total)}</span>
                    </div>
                  )}

                  {/* Room Tax Breakdown */}
                  {(details.charges?.room_cgst > 0 || details.charges?.package_cgst > 0) && (
                    <div className="flex justify-between text-sm text-gray-600 pl-4 border-l-2 border-indigo-200">
                      <span>CGST:</span>
                      <span>{formatCurrency((details.charges?.room_cgst || 0) + (details.charges?.package_cgst || 0))}</span>
                    </div>
                  )}
                  {(details.charges?.room_sgst > 0 || details.charges?.package_sgst > 0) && (
                    <div className="flex justify-between text-sm text-gray-600 pl-4 border-l-2 border-indigo-200">
                      <span>SGST:</span>
                      <span>{formatCurrency((details.charges?.room_sgst || 0) + (details.charges?.package_sgst || 0))}</span>
                    </div>
                  )}

                  <div className="flex justify-between pt-2 border-t font-semibold">
                    <span>Section Total:</span>
                    <span>{formatCurrency(
                      (details.room_total || 0) + (details.package_total || 0) +
                      ((details.charges?.room_gst || 0) + (details.charges?.package_gst || 0))
                    )}</span>
                  </div>
                </div>
              </div>
            )}

            {/* FOOD CHARGES SECTION */}
            {details.food_orders && details.food_orders.length > 0 && (
              <div className="border-t pt-4">
                <h3 className="text-lg font-semibold mb-3 text-indigo-700">Food & Beverage</h3>
                <div className="space-y-4">
                  {details.food_orders.map((order, idx) => (
                    <div key={idx} className="bg-gray-50 p-4 rounded-lg border border-gray-100">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-medium">Order #{order.id} <span className="text-xs text-gray-500">({order.room_number})</span></p>
                          <p className="text-xs text-gray-400">{new Date(order.created_at).toLocaleString()}</p>
                        </div>
                        <span className="font-semibold">{formatCurrency(order.amount)}</span>
                      </div>
                      <div className="mt-1 space-y-1 pl-2 border-l-2 border-gray-200">
                        {order.items?.map((item, itemIdx) => (
                          <div key={itemIdx} className="flex justify-between text-sm text-gray-600">
                            <span>{item.item_name} x {item.quantity}</span>
                            <span>{formatCurrency(item.total)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}

                  {/* Food Section Summary */}
                  <div className="bg-indigo-50 p-3 rounded-lg space-y-1 mt-2">
                    <div className="flex justify-between font-medium">
                      <span>Food Subtotal:</span>
                      <span>{formatCurrency(details.food_total)}</span>
                    </div>
                    {details.charges?.food_cgst > 0 && (
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>CGST (2.5%):</span>
                        <span>{formatCurrency(details.charges.food_cgst)}</span>
                      </div>
                    )}
                    {details.charges?.food_sgst > 0 && (
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>SGST (2.5%):</span>
                        <span>{formatCurrency(details.charges.food_sgst)}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-1 border-t border-indigo-200 font-bold text-indigo-700">
                      <span>Food Total:</span>
                      <span>{formatCurrency((details.food_total || 0) + (details.charges?.food_gst || 0))}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* SERVICE CHARGES SECTION */}
            {details.charges?.service_items && details.charges.service_items.length > 0 && (
              <div className="border-t pt-4">
                <h3 className="text-lg font-semibold mb-3 text-indigo-700">Services</h3>
                <div className="space-y-2">
                  {details.charges.service_items.map((service, idx) => (
                    <div key={idx} className="flex justify-between items-center bg-gray-50 p-3 rounded-lg border border-gray-100">
                      <div>
                        <p className="font-medium">
                          {service.service_name}
                          {service.quantity > 1 && <span className="text-sm text-gray-600"> (x{service.quantity})</span>}
                        </p>
                      </div>
                      <span className="font-semibold">{formatCurrency(service.charges)}</span>
                    </div>
                  ))}

                  {/* Service Section Summary */}
                  <div className="bg-indigo-50 p-3 rounded-lg space-y-1 mt-2">
                    <div className="flex justify-between font-medium">
                      <span>Services Subtotal:</span>
                      <span>{formatCurrency(details.service_total)}</span>
                    </div>
                    {details.charges?.service_cgst > 0 && (
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>CGST (2.5%):</span>
                        <span>{formatCurrency(details.charges.service_cgst)}</span>
                      </div>
                    )}
                    {details.charges?.service_sgst > 0 && (
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>SGST (2.5%):</span>
                        <span>{formatCurrency(details.charges.service_sgst)}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-1 border-t border-indigo-200 font-bold text-indigo-700">
                      <span>Services Total:</span>
                      <span>{formatCurrency((details.service_total || 0) + (details.charges?.service_gst || 0))}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Bill Summary - Grand Total Only */}
            <div className="border-t pt-4 mt-4">
              <h3 className="text-lg font-semibold mb-3">Invoice Summary</h3>
              <div className="space-y-2 bg-gray-100 p-4 rounded-xl">
                <div className="flex justify-between text-gray-600">
                  <span>Total Charges (Excl. Tax):</span>
                  <span className="font-medium">{formatCurrency(details.charges.total_due)}</span>
                </div>

                <div className="flex justify-between text-gray-600">
                  <span>Total Tax (CGST + SGST):</span>
                  <span className="font-medium">{formatCurrency(details.tax_amount)}</span>
                </div>

                {details.discount_amount > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Discount:</span>
                    <span className="font-medium">-{formatCurrency(details.discount_amount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-2xl font-bold text-indigo-700 pt-3 border-t border-gray-300 mt-2">
                  <span>Grand Total:</span>
                  <span>{formatCurrency(details.grand_total)}</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">Failed to load details</div>
        )}
      </div>
    </div>
  );
});
CheckoutDetailModal.displayName = 'CheckoutDetailModal';

const CHART_COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#3b82f6'];


const Billing = () => {
  const navigate = useNavigate(); // Not used here, but good practice if you use react-router for navigation
  const [roomNumber, setRoomNumber] = useState("");
  const [checkoutMode, setCheckoutMode] = useState("multiple");
  const [billData, setBillData] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("Card");
  const [discount, setDiscount] = useState(0);
  const [invoiceId, setInvoiceId] = useState(null); // New state for Invoice ID
  const [loading, setLoading] = useState(false);
  const [bannerMessage, setBannerMessage] = useState({ type: null, text: "" });
  const [activeRooms, setActiveRooms] = useState([]);
  const [checkouts, setCheckouts] = useState([]);
  const [selectedCheckout, setSelectedCheckout] = useState(null);
  const [hasMoreCheckouts, setHasMoreCheckouts] = useState(true);
  const [isFetchingMore, setIsFetchingMore] = useState(false);

  // Filter and search states
  const [searchQuery, setSearchQuery] = useState("");
  const [guestNameFilter, setGuestNameFilter] = useState("");
  const [roomNumberFilter, setRoomNumberFilter] = useState("");
  const [bookingIdFilter, setBookingIdFilter] = useState("");
  const [paymentMethodFilter, setPaymentMethodFilter] = useState("All");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [minAmount, setMinAmount] = useState("");
  const [maxAmount, setMaxAmount] = useState("");

  const [kpiData, setKpiData] = useState({
    checkouts_today: 0,
    checkouts_total: 0,
    available_rooms: 0,
    booked_rooms: 0,
    food_revenue_today: 0,
    package_bookings_today: 0,
  });

  const [chartData, setChartData] = useState({
    revenue_breakdown: [],
    weekly_performance: [],
  });

  // Function to show banner message
  const showBannerMessage = (type, text) => {
    setBannerMessage({ type, text });
  };

  const closeBannerMessage = () => {
    setBannerMessage({ type: null, text: "" });
  };

  const loadMoreCheckouts = useCallback(async () => {
    if (isFetchingMore || !hasMoreCheckouts) return;
    setIsFetchingMore(true);
    try {
      const response = await api.get(`/bill/checkouts?skip=${checkouts.length}&limit=20`);
      const newCheckouts = response.data || [];
      setCheckouts(prev => {
        const existingIds = new Set(prev.map(c => c.id));
        const uniqueNew = newCheckouts.filter(c => !existingIds.has(c.id));
        return [...prev, ...uniqueNew];
      });
      if (newCheckouts.length < 20) {
        setHasMoreCheckouts(false);
      }
    } catch (err) {
      console.error("Failed to load more checkouts:", err);
    } finally {
      setIsFetchingMore(false);
    }
  }, [isFetchingMore, hasMoreCheckouts, checkouts.length]);

  const loadMoreRef = useInfiniteScroll(loadMoreCheckouts, hasMoreCheckouts, isFetchingMore);

  // Extract unique payment methods from checkouts
  const paymentMethods = useMemo(() => {
    const methods = new Set();
    checkouts.forEach(c => {
      if (c.payment_method) methods.add(c.payment_method);
    });
    return Array.from(methods).sort();
  }, [checkouts]);

  // Filter checkouts based on all filter criteria
  const filteredCheckouts = useMemo(() => {
    return checkouts.filter(c => {
      // General search - search across ID, guest name, room number, booking ID
      if (searchQuery) {
        const searchLower = searchQuery.toLowerCase();
        const matchesSearch =
          c.id.toString().toLowerCase().includes(searchLower) ||
          c.guest_name?.toLowerCase().includes(searchLower) ||
          c.room_number?.toLowerCase().includes(searchLower) ||
          c.booking_id?.toString().toLowerCase().includes(searchLower) ||
          c.package_booking_id?.toString().toLowerCase().includes(searchLower);
        if (!matchesSearch) return false;
      }

      // Guest name filter
      if (guestNameFilter && !c.guest_name?.toLowerCase().includes(guestNameFilter.toLowerCase())) {
        return false;
      }

      // Room number filter
      if (roomNumberFilter && !c.room_number?.toLowerCase().includes(roomNumberFilter.toLowerCase())) {
        return false;
      }

      // Booking ID filter
      if (bookingIdFilter) {
        const bookingIdStr = bookingIdFilter.toLowerCase();
        const matchesBookingId =
          c.booking_id?.toString().toLowerCase().includes(bookingIdStr) ||
          c.package_booking_id?.toString().toLowerCase().includes(bookingIdStr);
        if (!matchesBookingId) return false;
      }

      // Payment method filter
      if (paymentMethodFilter !== "All" && c.payment_method !== paymentMethodFilter) {
        return false;
      }

      // Date range filter
      if (fromDate || toDate) {
        const checkoutDate = new Date(c.created_at);
        if (fromDate && checkoutDate < new Date(fromDate)) return false;
        if (toDate && checkoutDate > new Date(toDate + 'T23:59:59')) return false;
      }

      // Amount range filter
      if (minAmount && c.grand_total < parseFloat(minAmount)) return false;
      if (maxAmount && c.grand_total > parseFloat(maxAmount)) return false;

      return true;
    });
  }, [checkouts, searchQuery, guestNameFilter, roomNumberFilter, bookingIdFilter, paymentMethodFilter, fromDate, toDate, minAmount, maxAmount]);

  // Count active filters
  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (searchQuery) count++;
    if (guestNameFilter) count++;
    if (roomNumberFilter) count++;
    if (bookingIdFilter) count++;
    if (paymentMethodFilter !== "All") count++;
    if (fromDate) count++;
    if (toDate) count++;
    if (minAmount) count++;
    if (maxAmount) count++;
    return count;
  }, [searchQuery, guestNameFilter, roomNumberFilter, bookingIdFilter, paymentMethodFilter, fromDate, toDate, minAmount, maxAmount]);

  // Clear all filters
  const clearAllFilters = () => {
    setSearchQuery("");
    setGuestNameFilter("");
    setRoomNumberFilter("");
    setBookingIdFilter("");
    setPaymentMethodFilter("All");
    setFromDate("");
    setToDate("");
    setMinAmount("");
    setMaxAmount("");
  };

  const [resortInfo, setResortInfo] = useState(null);

  // Fetch initial data on component mount
  useEffect(() => {
    fetchInitialData();
    fetchResortInfo();
  }, []);

  const fetchResortInfo = async () => {
    try {
      const res = await api.get('/frontend/resort-info/');
      if (res.data && res.data.length > 0) {
        setResortInfo(res.data[0]);
      }
    } catch (err) {
      console.error("Failed to fetch resort info:", err);
    }
  };

  const fetchInitialData = async () => {
    try {
      // Fetch all necessary data in parallel using Promise.allSettled to handle individual failures
      const results = await Promise.allSettled([
        api.get("/bill/checkouts?skip=0&limit=20").catch(err => ({ error: err, data: [] })),
        api.get("/dashboard/kpis").catch(err => ({ error: err, data: [{ checkouts_today: 0, checkouts_total: 0, available_rooms: 0, booked_rooms: 0, food_revenue_today: 0, package_bookings_today: 0 }] })),
        api.get("/dashboard/charts").catch(err => ({ error: err, data: { revenue_breakdown: [], weekly_performance: [] } })),
        api.get("/bill/active-rooms").catch(err => ({ error: err, data: [] }))
      ]);

      // Process checkouts result
      if (results[0].status === 'fulfilled' && !results[0].value.error) {
        setCheckouts(Array.isArray(results[0].value.data) ? results[0].value.data : []);
        setHasMoreCheckouts(results[0].value.data && results[0].value.data.length === 20);
      } else {
        console.error("Failed to load checkouts:", results[0].value?.error || results[0].reason);
        setCheckouts([]);
        setHasMoreCheckouts(false);
      }

      // Process KPI result
      if (results[1].status === 'fulfilled' && !results[1].value.error) {
        const kpiData = results[1].value.data;
        if (Array.isArray(kpiData) && kpiData.length > 0) {
          setKpiData(kpiData[0]);
        } else if (typeof kpiData === 'object') {
          setKpiData(kpiData);
        } else {
          setKpiData({
            checkouts_today: 0,
            checkouts_total: 0,
            available_rooms: 0,
            booked_rooms: 0,
            food_revenue_today: 0,
            package_bookings_today: 0,
          });
        }
      } else {
        console.error("Failed to load KPIs:", results[1].value?.error || results[1].reason);
        setKpiData({
          checkouts_today: 0,
          checkouts_total: 0,
          available_rooms: 0,
          booked_rooms: 0,
          food_revenue_today: 0,
          package_bookings_today: 0,
        });
      }

      // Process charts result
      if (results[2].status === 'fulfilled' && !results[2].value.error) {
        setChartData(results[2].value.data || { revenue_breakdown: [], weekly_performance: [] });
      } else {
        console.error("Failed to load charts:", results[2].value?.error || results[2].reason);
        setChartData({ revenue_breakdown: [], weekly_performance: [] });
      }

      // Process active rooms result
      if (results[3].status === 'fulfilled' && !results[3].value.error) {
        setActiveRooms(Array.isArray(results[3].value.data) ? results[3].value.data : []);
      } else {
        console.error("Failed to load active rooms:", results[3].value?.error || results[3].reason);
        setActiveRooms([]);
      }

      // Show error message only if all requests failed
      const allFailed = results.every(r => r.status === 'rejected' || (r.status === 'fulfilled' && r.value?.error));
      if (allFailed) {
        showBannerMessage("error", "Could not fetch dashboard data. Please check your connection and try again.");
      }
    } catch (err) {
      console.error("Unexpected error fetching initial data:", err);
      showBannerMessage("error", `Could not fetch dashboard data: ${err.message || 'Unknown error'}. Please refresh.`);
      // Set default values to prevent undefined errors
      setCheckouts([]);
      setActiveRooms([]);
      setKpiData({
        checkouts_today: 0,
        checkouts_total: 0,
        available_rooms: 0,
        booked_rooms: 0,
        food_revenue_today: 0,
        package_bookings_today: 0,
      });
      setChartData({
        revenue_breakdown: [],
        weekly_performance: []
      });
    }
  };

  const handleGetBill = async () => {
    if (!roomNumber) {
      showBannerMessage("error", "Please select a booking to checkout.");
      return;
    }
    setLoading(true);
    setBillData(null);
    setInvoiceId(null);
    setDiscount(0); // Reset discount when fetching a new bill
    try {
      // Extract actual room number from composite key if needed
      const actualRoomNumber = roomNumber.includes('-') ? roomNumber.split('-')[1] : roomNumber;
      const res = await api.get(`/bill/${actualRoomNumber}?checkout_mode=${checkoutMode}`);
      if (res.data && res.data.room_numbers) {
        setBillData(res.data);
        const roomCount = res.data.room_numbers.length;
        const modeText = checkoutMode === "single" ? "single room" : "all rooms in the booking";
        showBannerMessage("success", `Bill retrieved for ${roomCount} room(s) (${modeText}).`);
      } else {
        throw new Error("Invalid bill data received");
      }
    } catch (error) {
      const errorMsg = error.response?.data?.detail;
      const message = typeof errorMsg === 'string' ? errorMsg : (error.message || 'Unknown error');
      showBannerMessage("error", `Error: ${message}`);
      setBillData(null);
      console.error("Error fetching bill:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckout = async () => {
    if (!billData) {
      showBannerMessage("error", "Please retrieve the bill before checkout.");
      return;
    }
    if (!roomNumber) {
      showBannerMessage("error", "No booking selected for checkout.");
      return;
    }
    // Validate discount amount
    const discountAmount = parseFloat(discount) || 0;
    if (discountAmount < 0) {
      showBannerMessage("error", "Discount amount cannot be negative.");
      return;
    }
    const totalWithGST = billData.charges.total_due + (billData.charges.total_gst || 0);
    if (discountAmount > totalWithGST) {
      showBannerMessage("error", "Discount cannot exceed the grand total.");
      return;
    }
    setLoading(true);
    try {
      // Extract actual room number from composite key if needed
      const actualRoomNumber = roomNumber.includes('-') ? roomNumber.split('-')[1] : roomNumber;
      const res = await api.post(`/bill/checkout/${actualRoomNumber}`, {
        payment_method: paymentMethod,
        discount_amount: discountAmount,
        checkout_mode: checkoutMode,
      });

      // --- PDF Upload Logic ---
      const checkoutId = res.data.checkout_id;

      // 1. Set Invoice ID and wait for render so html2canvas captures it
      setInvoiceId(checkoutId);
      await new Promise(resolve => setTimeout(resolve, 150));

      // Generate PDF blob immediately with the new checkout ID
      const pdfBlob = await generatePDF('blob', checkoutId);
      if (pdfBlob) {
        const formData = new FormData();
        // The filename on server is generated, but we pass a name here for the form
        formData.append('file', pdfBlob, `bill_${checkoutId}.pdf`);

        try {
          await api.post(`/bill/checkout/${checkoutId}/upload-pdf`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
          });
          console.log("PDF uploaded successfully");
        } catch (uploadErr) {
          console.error("Failed to upload generated PDF:", uploadErr);
          showBannerMessage("warning", `Checkout successful, but PDF upload failed: ${uploadErr.message}`);
        }
      }

      const roomCount = billData.room_numbers?.length || 1;
      const modeText = checkoutMode === "single" ? "single room" : "all rooms";
      setBillData(null);
      setDiscount(0);
      setInvoiceId(null);
      setRoomNumber(""); // Clear input on successful checkout
      setCheckoutMode("multiple"); // Reset to default
      showBannerMessage("success", `Checkout successful! ${roomCount} room(s) (${modeText}) checked out. Checkout ID: ${res.data.checkout_id}`);
      // Refresh all data after successful checkout
      setTimeout(() => {
        fetchInitialData();
      }, 1000);
    } catch (error) {
      const errorMessage = error.response?.data?.detail || error.message || "Checkout failed";
      showBannerMessage("error", `Error: ${errorMessage}`);
      // If it's a conflict error, it means it's already checked out. Clear the form.
      if (error.response?.status === 409) {
        setBillData(null);
        setDiscount(0);
        setRoomNumber("");
        // Refresh active rooms list
        setTimeout(() => {
          fetchInitialData();
        }, 1000);
      } else if (error.response?.status === 404) {
        // Booking not found - might have been checked out already
        setBillData(null);
        setRoomNumber("");
        setTimeout(() => {
          fetchInitialData();
        }, 1000);
      }
      console.error("Checkout error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBill = () => {
    setBillData(null);
    setInvoiceId(null);
    setDiscount(0);
    showBannerMessage("success", "Bill cancelled. You can select another room.");
  };

  const generatePDF = async (action = 'print', specificInvoiceId = null) => {
    if (!billData) return;

    try {
      const doc = new jsPDF();

      // --- HEADER ---
      doc.setFontSize(22);
      doc.setTextColor(40, 40, 40);
      doc.setFont("helvetica", "bold");
      const resortName = resortInfo?.name || 'Pomma Resort';
      doc.text(resortName, 105, 20, { align: "center" });

      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      const address = resortInfo?.address || resortInfo?.property_location || 'Munnar, Kerala';
      const email = resortInfo?.support_email || resortInfo?.email || 'contact@pommaholidays.com';
      doc.text(address, 105, 26, { align: "center" });
      doc.text(email, 105, 31, { align: "center" });

      if (resortInfo?.gst_no) {
        doc.setFont("helvetica", "bold");
        doc.text(`GST No: ${resortInfo.gst_no}`, 105, 36, { align: "center" });
      }

      doc.line(10, 40, 200, 40); // Horizontal line

      // --- INVOICE DETAILS ---
      const detailsBody = [
        ['Invoice No', specificInvoiceId || invoiceId || 'Pending'],
        ['Guest Name', billData.guest_name],
        ['Rooms', `${billData.room_numbers.join(', ')} (${billData.room_numbers.length})`],
        ['Check-in', new Date(billData.check_in).toLocaleDateString()],
        ['Check-out', new Date(billData.check_out).toLocaleDateString()],
        ['Stay Duration', `${billData.stay_nights} nights`],
      ];
      if (billData.number_of_guests) detailsBody.push(['Guests', billData.number_of_guests]);

      doc.autoTable({
        startY: 45,
        body: detailsBody,
        theme: 'plain',
        styles: { fontSize: 10, cellPadding: 1.5, overflow: 'linebreak' },
        columnStyles: { 0: { fontStyle: 'bold', width: 40 } }
      });

      let finalY = doc.lastAutoTable.finalY + 10;

      //Helper to add title
      const addSectionTitle = (text, y) => {
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(79, 70, 229); // Indigo
        doc.text(text, 14, y);
        return y + 4;
      };

      // --- 1. ROOM CHARGES ---
      if (billData.charges.room_charges > 0 || billData.charges.package_charges > 0) {
        finalY = addSectionTitle("Room Charges", finalY);

        const roomBody = [];
        if (billData.charges.room_charges > 0) {
          roomBody.push([`Room Rent (${billData.stay_nights} nights)`, formatCurrency(billData.charges.room_charges)]);
        }
        if (billData.charges.package_charges > 0) {
          roomBody.push([`Package Charges (${billData.stay_nights} nights)`, formatCurrency(billData.charges.package_charges, false)]);
        }
        // GST
        const roomGST = (billData.charges.room_cgst || 0) + (billData.charges.package_cgst || 0) + (billData.charges.room_sgst || 0) + (billData.charges.package_sgst || 0);
        if (roomGST > 0) {
          roomBody.push(['Tax (CGST + SGST)', formatCurrency(roomGST, false)]);
        }
        // Section Total
        const roomTotal = (billData.charges.room_charges || 0) + (billData.charges.package_charges || 0) + roomGST;
        roomBody.push([{ content: 'Section Total', styles: { fontStyle: 'bold' } }, { content: formatCurrency(roomTotal, false), styles: { fontStyle: 'bold' } }]);

        doc.autoTable({
          startY: finalY,
          head: [['Description', 'Amount']],
          body: roomBody,
          theme: 'striped',
          headStyles: { fillColor: [79, 70, 229] },
          styles: { fontSize: 10 }
        });
        finalY = doc.lastAutoTable.finalY + 10;
      }

      // --- 2. FOOD CHARGES ---
      if (billData.charges.food_items.length > 0) {
        finalY = addSectionTitle("Food & Beverage", finalY);

        const foodBody = billData.charges.food_items.map(item => [
          `${item.item_name} (x${item.quantity})`,
          formatCurrency(item.amount, false)
        ]);

        // Subtotal
        foodBody.push([{ content: 'Subtotal', styles: { fontStyle: 'italic' } }, { content: formatCurrency(billData.charges.food_charges, false), styles: { fontStyle: 'italic' } }]);

        // Taxes
        const foodGST = (billData.charges.food_cgst || 0) + (billData.charges.food_sgst || 0);
        if (foodGST > 0) {
          foodBody.push(['Tax (CGST + SGST)', formatCurrency(foodGST, false)]);
        }

        // Section Total
        const foodTotal = (billData.charges.food_charges || 0) + (billData.charges.food_gst || 0);
        foodBody.push([{ content: 'Section Total', styles: { fontStyle: 'bold' } }, { content: formatCurrency(foodTotal, false), styles: { fontStyle: 'bold' } }]);

        doc.autoTable({
          startY: finalY,
          head: [['Item', 'Amount']],
          body: foodBody,
          theme: 'striped',
          headStyles: { fillColor: [79, 70, 229] },
          styles: { fontSize: 10 }
        });
        finalY = doc.lastAutoTable.finalY + 10;
      }

      // --- 3. SERVICE CHARGES ---
      if (billData.charges.service_items.length > 0) {
        finalY = addSectionTitle("Services", finalY);

        const serviceBody = billData.charges.service_items.map(item => [
          `${item.service_name}${item.quantity > 1 ? ` (x${item.quantity})` : ''}`,
          formatCurrency(item.charges, false)
        ]);

        // Subtotal
        serviceBody.push([{ content: 'Subtotal', styles: { fontStyle: 'italic' } }, { content: formatCurrency(billData.charges.service_charges, false), styles: { fontStyle: 'italic' } }]);

        // Taxes
        const serviceGST = (billData.charges.service_cgst || 0) + (billData.charges.service_sgst || 0);
        if (serviceGST > 0) {
          serviceBody.push(['Tax (CGST + SGST)', formatCurrency(serviceGST, false)]);
        }

        // Section Total
        const serviceTotal = (billData.charges.service_charges || 0) + (billData.charges.service_gst || 0);
        serviceBody.push([{ content: 'Section Total', styles: { fontStyle: 'bold' } }, { content: formatCurrency(serviceTotal, false), styles: { fontStyle: 'bold' } }]);

        doc.autoTable({
          startY: finalY,
          head: [['Service', 'Amount']],
          body: serviceBody,
          theme: 'striped',
          headStyles: { fillColor: [79, 70, 229] },
          styles: { fontSize: 10 }
        });
        finalY = doc.lastAutoTable.finalY + 10;
      }

      // --- SUMMARY ---
      // Check if we need a new page for summary
      if (finalY > 230) {
        doc.addPage();
        finalY = 20;
      }

      const grandTotal = Math.max(0, billData.charges.total_due + (billData.charges.total_gst || 0) - discount);
      doc.autoTable({
        startY: finalY,
        body: [
          ['Total Charges (Excl. Tax)', formatCurrency(billData.charges.total_due, false)],
          ['Total Tax (CGST + SGST)', `+${formatCurrency(billData.charges.total_gst || 0, false)}`],
          discount > 0 ? ['Discount', `-${formatCurrency(parseFloat(discount), false)}`] : null,
          ['Grand Total', { content: formatCurrency(grandTotal, false), styles: { fontSize: 14, fontStyle: 'bold', textColor: [79, 70, 229] } }]
        ].filter(Boolean),
        theme: 'plain',
        styles: { fontSize: 12, cellPadding: 2, halign: 'right' },
        columnStyles: { 0: { fontStyle: 'bold' } }
      });

      // --- OUTPUT ---
      if (action === 'blob') {
        return doc.output('blob');
      } else if (action === 'download') {
        doc.save(`Invoice_${billData.guest_name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
      } else { // Default to print
        doc.autoPrint();
        window.open(doc.output('bloburl'), '_blank');
      }

    } catch (err) {
      console.error("Error generating PDF:", err);
      showBannerMessage("error", "Failed to generate PDF invoice.");
    }
  };

  const generateBillText = (forWhatsApp = false) => {
    if (!billData) return "";

    const line = '----------------------------------------';
    const bold = (text) => forWhatsApp ? `*${text}*` : text.toUpperCase();

    let text = `${bold('Hotel Checkout Bill')}\n${line}\n`;
    text += `Guest Name: ${billData.guest_name}\n`;
    text += `Rooms: ${billData.room_numbers.join(', ')}\n`;
    text += `Check-in: ${new Date(billData.check_in).toLocaleDateString()}\n`;
    text += `Check-out: ${new Date(billData.check_out).toLocaleDateString()}\n`;
    if (resortInfo?.gst_no) {
      text += `GST No: ${resortInfo.gst_no}\n`;
    }
    text += `${line}\n\n`;

    // 1. ROOM CHARGES
    if (billData.charges.room_charges > 0 || billData.charges.package_charges > 0) {
      text += `${bold('ROOM CHARGES')}\n`;
      if (billData.charges.room_charges > 0) {
        text += `Room Rent: ${formatCurrency(billData.charges.room_charges)}\n`;
      }
      if (billData.charges.package_charges > 0) {
        text += `Package: ${formatCurrency(billData.charges.package_charges)}\n`;
      }

      const roomTax = (billData.charges.room_gst || 0) + (billData.charges.package_gst || 0);
      if (roomTax > 0) {
        text += `CGST: ${formatCurrency(roomTax / 2)}\n`;
        text += `SGST: ${formatCurrency(roomTax / 2)}\n`;
      }
      text += `Room Total: ${formatCurrency((billData.charges.room_charges || 0) + (billData.charges.package_charges || 0) + roomTax)}\n\n`;
    }

    // 2. FOOD CHARGES
    if (billData.charges.food_items.length > 0) {
      text += `${bold('FOOD & BEVERAGE')}\n`;
      billData.charges.food_items.forEach(item => {
        text += `- ${item.item_name} x${item.quantity}: ${formatCurrency(item.amount)}\n`;
      });
      text += `Subtotal: ${formatCurrency(billData.charges.food_charges)}\n`;
      if (billData.charges.food_gst > 0) {
        text += `CGST (2.5%): ${formatCurrency(billData.charges.food_cgst)}\n`;
        text += `SGST (2.5%): ${formatCurrency(billData.charges.food_sgst)}\n`;
      }
      text += `Food Total: ${formatCurrency((billData.charges.food_charges || 0) + (billData.charges.food_gst || 0))}\n\n`;
    }

    // 3. SERVICE CHARGES
    if (billData.charges.service_items.length > 0) {
      text += `${bold('SERVICES')}\n`;
      billData.charges.service_items.forEach(item => {
        text += `- ${item.service_name}${item.quantity > 1 ? ` (x${item.quantity})` : ''}: ${formatCurrency(item.charges)}\n`;
      });
      text += `Subtotal: ${formatCurrency(billData.charges.service_charges)}\n`;
      if (billData.charges.service_gst > 0) {
        text += `CGST (2.5%): ${formatCurrency(billData.charges.service_cgst)}\n`;
        text += `SGST (2.5%): ${formatCurrency(billData.charges.service_sgst)}\n`;
      }
      text += `Services Total: ${formatCurrency((billData.charges.service_charges || 0) + (billData.charges.service_gst || 0))}\n\n`;
    }

    text += `${line}\n`;
    text += `Subtotal (Excl. Tax): ${formatCurrency(billData.charges.total_due)}\n`;
    text += `Total Tax: ${formatCurrency(billData.charges.total_gst)}\n`;
    if (discount > 0) text += `Discount: -${formatCurrency(parseFloat(discount))}\n`;

    // Grand Total calculation
    const grandTotal = Math.max(0, billData.charges.total_due + (billData.charges.total_gst || 0) - (parseFloat(discount) || 0));
    text += `${bold('GRAND TOTAL: ' + formatCurrency(grandTotal))}\n`;
    text += `${line}\n`;
    text += `Thank you for staying with us!`;

    return text;
  };


  const handleShareFile = async (type) => {
    try {
      const pdfBlob = generatePDF('blob');
      if (!pdfBlob) {
        showBannerMessage("error", "Failed to generate PDF for sharing.");
        return;
      }

      const fileName = `Invoice_${billData.guest_name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
      const file = new File([pdfBlob], fileName, { type: 'application/pdf' });

      const shareData = {
        title: 'Hotel Invoice',
        text: `Please find attached your invoice for Room(s) ${billData.room_numbers.join(', ')} at ${resortInfo?.name || 'Pomma Resort'}.`,
        files: [file]
      };

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share(shareData);
        showBannerMessage("success", "Shared successfully!");
      } else {
        // Fallback for browsers that don't support file sharing natively
        if (type === 'whatsapp') {
          const billText = generateBillText(true);
          window.open(`https://wa.me/?text=${encodeURIComponent('Please find your invoice details below:\\n\\n' + billText)}`, '_blank');
        } else {
          const subject = encodeURIComponent(`Your Hotel Invoice - ${resortInfo?.name || 'Pomma Resort'}`);
          const body = encodeURIComponent('Please find your invoice details below:\\n\\n' + generateBillText(false));
          window.location.href = `mailto:?subject=${subject}&body=${body}`;
        }
        showBannerMessage("info", "File attachment not supported on this browser. Sending text instead.");
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        console.error("Error sharing:", err);
        showBannerMessage("error", "Failed to share file.");
      }
    }
  };

  const handleWhatsAppShare = () => handleShareFile('whatsapp');
  const handleEmailShare = () => handleShareFile('email');

  return (
    <DashboardLayout>
      <BannerMessage
        message={bannerMessage}
        onClose={closeBannerMessage}
        autoDismiss={true}
        duration={5000}
      />
      {/* Animated Background */}


      <div className="p-2 sm:p-4 md:p-6 bg-gray-50 min-h-screen">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-800 mb-4 sm:mb-6">Business Dashboard & Checkout</h1>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 sm:gap-4 mb-6 sm:mb-8">
          <KpiCard title="Checkouts Today" value={kpiData.checkouts_today} icon={<Hash size={22} className="text-indigo-600" />} color="bg-indigo-100" />
          <KpiCard title="Total Checkouts" value={kpiData.checkouts_total} icon={<Hash size={22} className="text-green-600" />} color="bg-green-100" />
          <KpiCard title="Available Rooms" value={kpiData.available_rooms} icon={<BedDouble size={22} className="text-blue-600" />} color="bg-blue-100" />
          <KpiCard title="Booked Rooms" value={kpiData.booked_rooms} icon={<BedDouble size={22} className="text-red-600" />} color="bg-red-100" />
          <KpiCard title="Food Revenue Today" value={kpiData.food_revenue_today.toLocaleString()} prefix="₹" icon={<Utensils size={22} className="text-yellow-600" />} color="bg-yellow-100" />
          <KpiCard title="Package Bookings Today" value={kpiData.package_bookings_today} icon={<Package size={22} className="text-purple-600" />} color="bg-purple-100" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 sm:gap-6 md:gap-8 mb-6 sm:mb-8">
          <div className="lg:col-span-3 bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Weekly Performance</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData.weekly_performance} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <XAxis dataKey="day" stroke="#6b7280" />
                <YAxis yAxisId="left" stroke="#6b7280" />
                <YAxis yAxisId="right" orientation="right" stroke="#6b7280" />
                <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #ddd' }} />
                <Legend />
                <Bar yAxisId="left" dataKey="revenue" fill="#4f46e5" name="Revenue (₹)" />
                <Bar yAxisId="right" dataKey="checkouts" fill="#10b981" name="Checkouts" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Total Revenue Breakdown</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={chartData.revenue_breakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                  {chartData.revenue_breakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Checkout Form */}
        <div className="bg-white p-4 sm:p-6 md:p-8 rounded-xl shadow-md w-full max-w-2xl mx-auto mb-6 sm:mb-8">
          <h2 className="text-xl sm:text-2xl font-bold text-center text-gray-800 mb-4 sm:mb-6">Process New Checkout</h2>
          <div className="mb-4">
            <label htmlFor="room-select" className="block text-gray-700 font-medium mb-2">
              Select a Room or Booking to Checkout
            </label>
            <select
              id="room-select"
              value={roomNumber}
              onChange={(e) => {
                const value = e.target.value;
                if (!value) {
                  setRoomNumber("");
                  setCheckoutMode("multiple");
                  setBillData(null);
                  return;
                }
                // Use composite key: booking_id-room_number-checkout_mode
                const parts = value.split('-');
                if (parts.length >= 3) {
                  const [bookingId, roomNum, mode] = parts;
                  const selected = activeRooms.find(b =>
                    b.booking_id.toString() === bookingId &&
                    b.room_number === roomNum &&
                    b.checkout_mode === mode
                  );
                  setRoomNumber(value);
                  if (selected) {
                    setCheckoutMode(selected.checkout_mode || mode || "multiple");
                    setBillData(null); // Clear bill data when selection changes
                  }
                } else {
                  // Fallback for old format (shouldn't happen, but just in case)
                  const selected = activeRooms.find(b => b.room_number === value);
                  setRoomNumber(value);
                  if (selected) {
                    setCheckoutMode(selected.checkout_mode || "multiple");
                    setBillData(null);
                  }
                }
              }}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">-- Select a Room or Booking to Checkout --</option>
              {activeRooms.map((booking, index) => {
                // Create unique composite key: booking_id-room_number-checkout_mode
                const uniqueValue = `${booking.booking_id}-${booking.room_number}-${booking.checkout_mode}`;
                return (
                  <option key={`${uniqueValue}-${index}`} value={uniqueValue}>
                    {booking.display_label || `${booking.room_numbers?.join(', ') || booking.room_number} (${booking.guest_name})`}
                  </option>
                );
              })}
            </select>
            {roomNumber && (() => {
              // Parse composite key to find the correct selection
              let selected = null;
              let actualMode = "multiple";

              if (roomNumber.includes('-')) {
                const parts = roomNumber.split('-');
                if (parts.length >= 3) {
                  const [bookingId, roomNum, mode] = parts;
                  selected = activeRooms.find(b =>
                    b.booking_id.toString() === bookingId &&
                    b.room_number === roomNum &&
                    b.checkout_mode === mode
                  );
                  actualMode = selected?.checkout_mode || mode || "multiple";
                }
              } else {
                // Fallback for old format
                selected = activeRooms.find(b => b.room_number === roomNumber);
                actualMode = selected?.checkout_mode || "multiple";
              }

              const isMultiple = actualMode === "multiple";
              return (
                <div className={`mt-2 p-3 ${isMultiple ? 'bg-blue-50 border-blue-200' : 'bg-green-50 border-green-200'} border rounded-lg text-sm ${isMultiple ? 'text-blue-800' : 'text-green-800'}`}>
                  <p className="font-semibold">
                    {isMultiple ? "⚠️ Important: This will checkout ALL rooms in the booking" : "✓ Single Room Checkout: Only this room will be checked out"}
                  </p>
                  <p className="mt-1">Rooms: {selected?.room_numbers?.join(', ') || roomNumber}</p>
                  {selected?.room_numbers && selected.room_numbers.length > 1 && !isMultiple && (
                    <p className="mt-1 text-xs italic">Other rooms in this booking will remain checked in.</p>
                  )}
                </div>
              );
            })()}
          </div>
          <button
            onClick={handleGetBill}
            className="w-full bg-indigo-600 text-white py-2.5 rounded-lg font-semibold hover:bg-indigo-700 transition duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 mb-4"
            disabled={loading}
          >
            {loading ? "Fetching Bill..." : checkoutMode === "single" ? "Get Bill for Single Room" : "Get Bill for Entire Booking"}
          </button>

          {billData && (
            <div id="bill-details" className="bg-gray-50 border border-gray-200 p-4 rounded-xl mb-6 animate-fade-in">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-800">Detailed Bill</h2>
                <button
                  onClick={handleCancelBill}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition duration-200 font-medium"
                  title="Cancel and clear bill"
                >
                  <X size={18} />
                  Cancel
                </button>
              </div>

              {/* Logo and GST Header */}
              <div className="flex justify-between items-start mb-6 border-b pb-4">
                <img src={pommaLogo} alt="Pomma Holidays" className="h-16 object-contain" />
                <div className="text-right text-sm text-gray-900">
                  <p className="font-bold text-gray-800 text-lg">{resortInfo?.name || 'Pomma Resort'}</p>
                  <p className="whitespace-pre-line">{resortInfo?.address || resortInfo?.property_location || 'Munnar, Kerala'}</p>
                  <p>{resortInfo?.support_email || resortInfo?.email || 'contact@pommaholidays.com'}</p>
                  {resortInfo?.gst_no && <p className="font-semibold text-gray-800">GST No: {resortInfo.gst_no}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-x-4 gap-y-2 mb-4 text-sm">
                <p><span className="font-semibold">Invoice No:</span> {invoiceId || 'Pending'}</p>
                <p><span className="font-semibold">Guest Name:</span> {billData.guest_name}</p>
                <p><span className="font-semibold">Rooms:</span> {billData.room_numbers.join(', ')} ({billData.room_numbers.length})</p>
                <p><span className="font-semibold">Check-in:</span> {new Date(billData.check_in).toLocaleDateString()}</p>
                <p><span className="font-semibold">Check-out:</span> {new Date(billData.check_out).toLocaleDateString()}</p>
                <p><span className="font-semibold">Stay:</span> {billData.stay_nights} nights</p>
                <p><span className="font-semibold">Guests:</span> {billData.number_of_guests}</p>
              </div>

              <div className="mt-4 pt-4 border-t">
                <div className="mt-4 pt-4 border-t space-y-6">

                  {/* 1. ROOM CHARGES */}
                  {(billData.charges.room_charges > 0 || billData.charges.package_charges > 0) && (
                    <div>
                      <h3 className="font-semibold text-indigo-700 mb-2 border-b pb-1">Room Charges</h3>
                      <ul className="space-y-1 text-sm text-gray-800">
                        {billData.charges.room_charges > 0 && (
                          <li className="flex justify-between">
                            <span>Room Rent ({billData.stay_nights} nights)</span>
                            <span>{formatCurrency(billData.charges.room_charges)}</span>
                          </li>
                        )}
                        {billData.charges.package_charges > 0 && (
                          <li className="flex justify-between">
                            <span>Package Charges ({billData.stay_nights} nights)</span>
                            <span>{formatCurrency(billData.charges.package_charges)}</span>
                          </li>
                        )}

                        {/* Room GST Breakdown */}
                        {(billData.charges.room_cgst > 0 || billData.charges.package_cgst > 0) && (
                          <li className="flex justify-between text-gray-800 pl-4 border-l-2 border-indigo-100">
                            <span>CGST</span>
                            <span>{formatCurrency((billData.charges.room_cgst || 0) + (billData.charges.package_cgst || 0))}</span>
                          </li>
                        )}
                        {(billData.charges.room_sgst > 0 || billData.charges.package_sgst > 0) && (
                          <li className="flex justify-between text-gray-800 pl-4 border-l-2 border-indigo-100">
                            <span>SGST</span>
                            <span>{formatCurrency((billData.charges.room_sgst || 0) + (billData.charges.package_sgst || 0))}</span>
                          </li>
                        )}
                        <li className="flex justify-between font-medium pt-1 border-t border-gray-100 mt-1">
                          <span>Section Total</span>
                          <span>{formatCurrency((billData.charges.room_charges || 0) + (billData.charges.package_charges || 0) + (billData.charges.room_gst || 0) + (billData.charges.package_gst || 0))}</span>
                        </li>
                      </ul>
                    </div>
                  )}

                  {/* 2. FOOD CHARGES */}
                  {billData.charges.food_items.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-indigo-700 mb-2 border-b pb-1">Food & Beverage</h3>
                      <ul className="space-y-1 text-sm text-gray-800">
                        {billData.charges.food_items.map((item, i) => (
                          <li key={i} className="flex justify-between">
                            <span>{item.item_name} (x{item.quantity})</span>
                            <span>{formatCurrency(item.amount)}</span>
                          </li>
                        ))}

                        <div className="pl-4 mt-2 border-l-2 border-indigo-100 space-y-1">
                          <li className="flex justify-between text-gray-900 font-medium">
                            <span>Subtotal</span>
                            <span>{formatCurrency(billData.charges.food_charges)}</span>
                          </li>
                          {billData.charges.food_cgst > 0 && (
                            <li className="flex justify-between text-gray-800">
                              <span>CGST (2.5%)</span>
                              <span>{formatCurrency(billData.charges.food_cgst)}</span>
                            </li>
                          )}
                          {billData.charges.food_sgst > 0 && (
                            <li className="flex justify-between text-gray-800">
                              <span>SGST (2.5%)</span>
                              <span>{formatCurrency(billData.charges.food_sgst)}</span>
                            </li>
                          )}
                        </div>

                        <li className="flex justify-between font-medium pt-1 border-t border-gray-100 mt-1">
                          <span>Section Total</span>
                          <span>{formatCurrency((billData.charges.food_charges || 0) + (billData.charges.food_gst || 0))}</span>
                        </li>
                      </ul>
                    </div>
                  )}

                  {/* 3. SERVICE CHARGES */}
                  {billData.charges.service_items.length > 0 && (
                    <div>
                      <h3 className="font-semibold text-indigo-700 mb-2 border-b pb-1">Services</h3>
                      <ul className="space-y-1 text-sm text-gray-800">
                        {billData.charges.service_items.map((item, i) => (
                          <li key={i} className="flex justify-between">
                            <span>{item.service_name}{item.quantity > 1 && ` (x${item.quantity})`}</span>
                            <span>{formatCurrency(item.charges)}</span>
                          </li>
                        ))}

                        <div className="pl-4 mt-2 border-l-2 border-indigo-100 space-y-1">
                          <li className="flex justify-between text-gray-900 font-medium">
                            <span>Subtotal</span>
                            <span>{formatCurrency(billData.charges.service_charges)}</span>
                          </li>
                          {billData.charges.service_cgst > 0 && (
                            <li className="flex justify-between text-gray-800">
                              <span>CGST (2.5%)</span>
                              <span>{formatCurrency(billData.charges.service_cgst)}</span>
                            </li>
                          )}
                          {billData.charges.service_sgst > 0 && (
                            <li className="flex justify-between text-gray-800">
                              <span>SGST (2.5%)</span>
                              <span>{formatCurrency(billData.charges.service_sgst)}</span>
                            </li>
                          )}
                        </div>

                        <li className="flex justify-between font-medium pt-1 border-t border-gray-100 mt-1">
                          <span>Section Total</span>
                          <span>{formatCurrency((billData.charges.service_charges || 0) + (billData.charges.service_gst || 0))}</span>
                        </li>
                      </ul>
                    </div>
                  )}

                  {/* GRAND TOTAL SUMMARY */}
                  <div className="mt-4 pt-4 border-t text-right space-y-1 bg-gray-50 p-3 rounded-lg">
                    <div className="flex justify-between text-sm text-gray-900 font-medium">
                      <span>Total Charges (Excl. Tax):</span>
                      <span>{formatCurrency(billData.charges.total_due)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-900 font-medium">
                      <span>Total Tax (CGST + SGST):</span>
                      <span>+{formatCurrency(billData.charges.total_gst || 0)}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-sm text-red-600">
                        <span>Discount:</span>
                        <span>-{formatCurrency(parseFloat(discount))}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-xl text-indigo-700 pt-2 border-t border-gray-200 mt-2">
                      <span>Grand Total:</span>
                      <span>{formatCurrency(Math.max(0, billData.charges.total_due + (billData.charges.total_gst || 0) - discount))}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {billData && (
            <>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label htmlFor="discount" className="block text-gray-700 font-medium mb-2">Discount (₹)</label>
                  <input type="number" id="discount" value={discount} onChange={e => setDiscount(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="0.00" />
                </div>
                <div>
                  <label htmlFor="payment-method" className="block text-gray-700 font-medium mb-2">Payment Method</label>
                  <select
                    id="payment-method"
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg h-full focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Card">Card</option>
                    <option value="Cash">Cash</option>
                    <option value="Online">Online</option>
                  </select>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex space-x-2">
                  <button onClick={() => generatePDF('print')} className="flex-1 bg-gray-500 text-white py-2 rounded-lg font-semibold hover:bg-gray-600 transition">Print</button>
                  <button onClick={() => generatePDF('download')} className="flex-1 bg-indigo-500 text-white py-2 rounded-lg font-semibold hover:bg-indigo-600 transition">Download</button>
                  <button onClick={handleWhatsAppShare} className="flex-1 bg-green-500 text-white py-2 rounded-lg font-semibold hover:bg-green-600 transition">WhatsApp</button>
                  <button onClick={handleEmailShare} className="flex-1 bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition">Email</button>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full bg-red-600 text-white py-3 rounded-lg font-bold text-lg hover:bg-red-700 transition duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  disabled={loading}
                >
                  {loading ? "Processing..." : "Complete Checkout"}
                </button>
              </div>
            </>
          )}
        </div>

        {/* All Checkouts Report */}
        <div className="bg-white p-3 sm:p-6 rounded-xl shadow-md w-full max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 gap-3">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Completed Checkouts</h2>
            {activeFiltersCount > 0 && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>Showing {filteredCheckouts.length} of {checkouts.length} checkouts</span>
                <button
                  onClick={clearAllFilters}
                  className="flex items-center gap-1 px-3 py-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                >
                  <XCircle size={14} />
                  Clear Filters ({activeFiltersCount})
                </button>
              </div>
            )}
          </div>

          {/* Filters Section */}
          <div className="bg-gray-50 p-4 rounded-lg mb-4 border border-gray-200">
            <div className="flex items-center gap-2 mb-3">
              <Filter size={18} className="text-indigo-600" />
              <h3 className="font-semibold text-gray-800">Filters & Search</h3>
            </div>

            {/* General Search */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by ID, guest name, room number, booking ID..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Filter Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Guest Name Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Guest Name</label>
                <input
                  type="text"
                  value={guestNameFilter}
                  onChange={(e) => setGuestNameFilter(e.target.value)}
                  placeholder="Filter by guest name"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>

              {/* Room Number Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Room Number</label>
                <input
                  type="text"
                  value={roomNumberFilter}
                  onChange={(e) => setRoomNumberFilter(e.target.value)}
                  placeholder="Filter by room number"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>

              {/* Booking/Package ID Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Booking/Package ID</label>
                <input
                  type="text"
                  value={bookingIdFilter}
                  onChange={(e) => setBookingIdFilter(e.target.value)}
                  placeholder="Filter by booking ID"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>

              {/* Payment Method Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
                <select
                  value={paymentMethodFilter}
                  onChange={(e) => setPaymentMethodFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm bg-white"
                >
                  <option value="All">All Methods</option>
                  {paymentMethods.map((method) => (
                    <option key={method} value={method}>{method}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Date Range and Amount Filters */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
              {/* From Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">From Date</label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>

              {/* To Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">To Date</label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>

              {/* Min Amount */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Min Amount (₹)</label>
                <input
                  type="number"
                  value={minAmount}
                  onChange={(e) => setMinAmount(e.target.value)}
                  placeholder="0"
                  min="0"
                  step="0.01"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>

              {/* Max Amount */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Amount (₹)</label>
                <input
                  type="number"
                  value={maxAmount}
                  onChange={(e) => setMaxAmount(e.target.value)}
                  placeholder="No limit"
                  min="0"
                  step="0.01"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
              </div>
            </div>
          </div>

          <div className="overflow-x-auto -mx-2 sm:mx-0">
            <table className="min-w-full text-xs sm:text-sm text-left">
              <thead className="bg-gray-50 border-b-2 border-gray-200 text-gray-800 uppercase tracking-wider">
                <tr>
                  <th className="p-2 sm:p-3">ID</th>
                  <th className="p-2 sm:p-3 hidden sm:table-cell">Guest</th>
                  <th className="p-2 sm:p-3">Rooms</th>
                  <th className="p-2 sm:p-3 hidden lg:table-cell">Booking/Package ID</th>
                  <th className="p-2 sm:p-3 hidden md:table-cell">Payment</th>
                  <th className="p-2 sm:p-3 hidden lg:table-cell">Date</th>
                  <th className="p-2 sm:p-3 text-right">Total</th>
                  <th className="p-2 sm:p-3 text-center">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredCheckouts.length > 0 ? (
                  filteredCheckouts.map((c) => (
                    <tr key={c.id} className="hover:bg-indigo-50 cursor-pointer" onClick={() => {
                      if (c.pdf_url) {
                        let pdfUrl = c.pdf_url;
                        if (!pdfUrl.startsWith('http')) {
                          pdfUrl = getApiBaseUrl().replace('/api', '') + pdfUrl;
                        }
                        window.open(pdfUrl, '_blank');
                      } else {
                        setSelectedCheckout(c);
                      }
                    }}>
                      <td className="p-2 sm:p-3 font-medium text-gray-800 text-xs sm:text-sm">{c.id}</td>
                      <td className="p-2 sm:p-3 font-semibold text-gray-900 text-xs sm:text-sm hidden sm:table-cell">{c.guest_name}</td>
                      <td className="p-2 sm:p-3 text-gray-800 text-xs sm:text-sm">{c.room_number}</td>
                      <td className="p-2 sm:p-3 text-gray-800 text-xs sm:text-sm hidden lg:table-cell">{c.booking_id || c.package_booking_id || 'N/A'}</td>
                      <td className="p-2 sm:p-3 text-gray-800 text-xs sm:text-sm hidden md:table-cell">{c.payment_method}</td>
                      <td className="p-2 sm:p-3 text-gray-800 text-xs sm:text-sm hidden lg:table-cell">{new Date(c.created_at).toLocaleDateString()}</td>
                      <td className="p-2 sm:p-3 font-bold text-gray-900 text-right text-xs sm:text-sm">{formatCurrency(c.grand_total)}</td>
                      <td className="p-2 sm:p-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            if (c.pdf_url) {
                              let pdfUrl = c.pdf_url;
                              if (!pdfUrl.startsWith('http')) {
                                pdfUrl = getApiBaseUrl().replace('/api', '') + pdfUrl;
                              }
                              window.open(pdfUrl, '_blank');
                            } else {
                              // Fallback: open details view (which has download option)
                              setSelectedCheckout(c);
                            }
                          }}
                          className={`${c.pdf_url ? 'text-indigo-600 hover:text-indigo-900' : 'text-gray-400'} transition-colors`}
                          title={c.pdf_url ? "Download Saved Bill" : "View Details"}
                        >
                          <CreditCard size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="8" className="p-4 text-center text-gray-500 text-sm sm:text-base">
                      {activeFiltersCount > 0 ? (
                        <div className="flex flex-col items-center gap-2">
                          <span>No checkouts match your filters.</span>
                          <button
                            onClick={clearAllFilters}
                            className="text-indigo-600 hover:text-indigo-800 underline text-sm"
                          >
                            Clear all filters
                          </button>
                        </div>
                      ) : (
                        "No completed checkouts found."
                      )}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {hasMoreCheckouts && (
            <div ref={loadMoreRef} className="text-center p-4">
              {isFetchingMore && <span className="text-indigo-600">Loading more checkouts...</span>}
            </div>
          )}
        </div>

        <CheckoutDetailModal checkout={selectedCheckout} onClose={() => setSelectedCheckout(null)} />
      </div>
    </DashboardLayout>
  );
};



export default Billing;
