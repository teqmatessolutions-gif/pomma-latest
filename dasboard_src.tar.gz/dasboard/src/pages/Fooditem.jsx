import React, { useEffect, useState } from "react";
import { getImageUrl } from "../utils/image";
import DashboardLayout from "../layout/DashboardLayout";
import BannerMessage from "../components/BannerMessage";
import API from "../services/api";
import { getMediaBaseUrl } from "../utils/env";
import Modal from "../components/Modal";

// Helper function to construct image URLs


const bgColors = [
  "bg-red-50",
  "bg-green-50",
  "bg-yellow-50",
  "bg-blue-100",
  "bg-purple-50",
  "bg-pink-50",
  "bg-orange-50",
];

const FoodItems = () => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [message, setMessage] = useState({ type: "", text: "" });
  const [images, setImages] = useState([]);
  const [existingImages, setExistingImages] = useState([]); // Store existing images {id, image_url}
  const [imagePreviews, setImagePreviews] = useState([]);
  const [foodItems, setFoodItems] = useState([]);
  const [editingItemId, setEditingItemId] = useState(null);
  const [available, setAvailable] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchCategories();
    fetchFoodItems();
  }, []);

  const fetchCategories = async () => {
    try {
      const res = await API.get("/food-categories", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCategories(res.data);
    } catch (err) {
      console.error("Failed to load categories:", err);
    }
  };

  const fetchFoodItems = async () => {
    try {
      const res = await API.get("/food-items", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFoodItems(res.data);
    } catch (err) {
      console.error("Failed to fetch items", err);
    }
  };

  const handleImageChange = async (e) => {
    const newFiles = Array.from(e.target.files);
    setImages((prevImages) => [...prevImages, ...newFiles]);
    const newPreviews = await Promise.all(newFiles.map(file => {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(file);
      });
    }));
    setImagePreviews((prev) => [...prev, ...newPreviews]);
  };

  const handleRemoveImage = (index) => {
    // Determine if the index refers to an existing image or a new file
    // The previews list combines existing (first) + new (second)
    const existingCount = existingImages.length;

    if (index < existingCount) {
      // Removing an existing image
      setExistingImages((prev) => prev.filter((_, i) => i !== index));
    } else {
      // Removing a new file
      // Adjust index to map to 'images' array (index - existingCount)
      const newFileIndex = index - existingCount;
      setImages((prev) => prev.filter((_, i) => i !== newFileIndex));
    }
    // Always remove from previews
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleEdit = (item) => {
    setEditingItemId(item.id);
    setName(item.name);
    setDescription(item.description);
    setPrice(item.price);
    setSelectedCategory(item.category_id);
    setAvailable(item.available);

    // Set existing images
    setExistingImages(item.images || []);

    // Generate previews: Existing images + New Files (none initially)
    const existingPreviews = item.images?.map((img) => getImageUrl(img.image_url, false)) || [];
    setImagePreviews(existingPreviews);

    setImages([]); // Clear new file uploads
    setIsModalOpen(true);
  };

  const resetForm = () => {
    setName("");
    setDescription("");
    setPrice("");
    setSelectedCategory("");
    setImages([]);
    setExistingImages([]);
    setImagePreviews([]);
    setEditingItemId(null);
    setAvailable(true);
    setMessage({ type: "", text: "" });
    setIsModalOpen(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!name.trim()) {
      setMessage({ type: "error", text: "Please enter food item name" });
      return;
    }
    if (!description.trim()) {
      setMessage({ type: "error", text: "Please enter description" });
      return;
    }
    if (!price || parseFloat(price) <= 0) {
      setMessage({ type: "error", text: "Please enter a valid price" });
      return;
    }
    if (!selectedCategory) {
      setMessage({ type: "error", text: "Please select a category" });
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("description", description);
    formData.append("price", price);
    formData.append("category_id", selectedCategory);
    formData.append("available", available);

    // Append new images
    images.forEach((img) => formData.append("images", img));

    // Append kept (existing) image IDs as comma-separated string (Package Logic)
    if (editingItemId) {
      if (existingImages.length > 0) {
        const keepIds = existingImages.map(img => img.id).join(",");
        formData.append("keep_image_ids", keepIds);
      } else {
        // If empty, send empty string to imply delete all existing
        formData.append("keep_image_ids", "");
      }
    }

    try {
      if (editingItemId) {
        await API.put(`/food-items/${editingItemId}`, formData, {
          headers: { Authorization: `Bearer ${token}` }, // Content-Type handled automatically
        });
        setMessage({ type: "success", text: "Food item updated successfully!" });
      } else {
        await API.post("/food-items", formData, {
          headers: { Authorization: `Bearer ${token}` }, // Content-Type handled automatically
        });
        setMessage({ type: "success", text: "Food item created successfully!" });
      }
      fetchFoodItems();
      resetForm();
      setIsModalOpen(false);
      // BannerMessage handles auto-dismiss
    } catch (err) {
      console.error("Failed to save food item", err);
      const errorMsg = err.response?.data?.detail || err.message || "Failed to save food item. Please try again.";
      setMessage({ type: "error", text: errorMsg });
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this item?")) return;
    try {
      await API.delete(`/food-items/${id}`, { headers: { Authorization: `Bearer ${token}` } });
      setMessage({ type: "success", text: "Food item deleted successfully!" });
      fetchFoodItems();
      fetchFoodItems();
      // BannerMessage handles auto-dismiss
    } catch (err) {
      console.error("Delete failed", err);
      const errorMsg = err.response?.data?.detail || "Failed to delete food item";
      setMessage({ type: "error", text: errorMsg });
      setMessage({ type: "error", text: errorMsg });
      // BannerMessage handles auto-dismiss
    }
  };

  const toggleAvailability = async (item) => {
    try {
      await API.patch(
        `/food-items/${item.id}/toggle-availability?available=${!item.available}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const newStatus = !item.available ? "Available" : "Not Available";
      setMessage({ type: "success", text: `Food item marked as ${newStatus}` });
      setMessage({ type: "success", text: `Food item marked as ${newStatus}` });
      fetchFoodItems();
      // BannerMessage handles auto-dismiss
    } catch (err) {
      console.error("Failed to toggle availability", err);
      const errorMsg = err.response?.data?.detail || "Failed to update availability";
      setMessage({ type: "error", text: errorMsg });
      setMessage({ type: "error", text: errorMsg });
      // BannerMessage handles auto-dismiss
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 flex flex-col items-center gap-8">
        {/* Success/Error Message */}
        {/* Success/Error Message */}
        <BannerMessage
          message={message}
          onClose={() => setMessage({ type: "", text: "" })}
          autoDismiss={true}
          duration={5000}
        />

        <div className="w-full max-w-6xl flex justify-between items-center mb-6">
          <h3 className="text-2xl font-semibold text-gray-700">Food Items Management</h3>
          <button
            onClick={() => {
              resetForm();
              setIsModalOpen(true);
            }}
            className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:scale-105 transform transition flex items-center gap-2"
          >
            <span>➕</span> Add New Food Item
          </button>
        </div>

        {/* Food Items Grid */}
        <div className="w-full max-w-6xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {foodItems.map((item, index) => (
              <div
                key={item.id}
                className={`relative border rounded-2xl p-4 shadow hover:shadow-2xl transition ${bgColors[index % bgColors.length]} group`}
              >
                <h4 className="font-semibold text-lg">{item.name}</h4>
                <p className="text-sm text-gray-600">{item.description}</p>
                <p className="text-sm mt-1 font-medium">₹{item.price}</p>
                <p className="text-sm text-gray-700 mt-1">
                  Status:{" "}
                  <span className={item.available ? "text-green-600" : "text-red-500"}>
                    {item.available ? "Available" : "Not Available"}
                  </span>
                </p>

                <div className="flex gap-2 mt-2 flex-wrap">
                  {item.images?.map((img, idx) => (
                    <img
                      key={idx}
                      src={getImageUrl(img.image_url, false)}
                      alt={`Food ${idx}`}
                      className="w-[60px] h-[60px] object-cover border rounded-xl shadow-sm hover:scale-110 transition"
                    />
                  ))}
                </div>

                {/* Inline Buttons */}
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => handleEdit(item)}
                    className="flex-1 px-3 py-1 text-sm bg-blue-600 text-white rounded-xl shadow hover:bg-blue-700 transition"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="flex-1 px-3 py-1 text-sm bg-red-600 text-white rounded-xl shadow hover:bg-red-700 transition"
                  >
                    Delete
                  </button>
                  <button
                    onClick={() => toggleAvailability(item)}
                    className="flex-1 px-3 py-1 text-sm bg-yellow-600 text-white rounded-xl shadow hover:bg-yellow-700 transition"
                  >
                    Toggle Availability
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>


      <Modal
        isOpen={isModalOpen}
        onClose={resetForm}
        title={editingItemId ? "Edit Food Item" : "Add New Food Item"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
            <input
              type="text"
              placeholder="Item Name"
              className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              placeholder="Item Description"
              className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹)</label>
              <input
                type="number"
                placeholder="0.00"
                className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
              <select
                className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 transition"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                required
              >
                <option value="">Select Category</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <label className="flex items-center gap-2 cursor-pointer bg-gray-50 p-3 rounded-xl border">
            <input
              type="checkbox"
              checked={available}
              onChange={() => setAvailable(!available)}
              className="w-5 h-5 text-green-600 rounded focus:ring-green-500"
            />
            <span className="text-gray-700 font-medium">Available for Order</span>
          </label>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Images</label>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageChange}
              className="w-full border rounded-xl px-4 py-2 mb-4 bg-gray-50"
            />

            {imagePreviews.length > 0 && (
              <div className="flex gap-2 flex-wrap mb-4">
                {imagePreviews.map((src, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={src}
                      alt={`Preview ${index}`}
                      className="w-16 h-16 object-cover border rounded-lg shadow-sm"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(index)}
                      className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition shadow-md"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={resetForm}
              className="flex-1 px-4 py-3 bg-gray-100 text-gray-700 font-bold rounded-xl hover:bg-gray-200 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 transform transition"
            >
              {editingItemId ? "Update Item" : "Create Item"}
            </button>
          </div>
        </form>
      </Modal>
    </DashboardLayout >
  );
};

export default FoodItems;
