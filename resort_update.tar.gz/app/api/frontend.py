from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from typing import Annotated, Any
from sqlalchemy.orm import Session
import os
import shutil
import uuid
from PIL import Image
import io

import app.schemas.frontend as schemas
import app.models.frontend as models
from app.models.user import User
import app.curd.frontend as crud
from app.utils.auth import get_db, get_current_user

router = APIRouter()

# Determine upload directory
UPLOAD_DIR = os.path.join("uploads", "cms")
os.makedirs(UPLOAD_DIR, exist_ok=True)  # Ensure directory exists at startup

# ---------- Header & Banner ----------
@router.get("/header-banner/", response_model=list[schemas.HeaderBanner])
def list_header_banner(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.HeaderBanner, skip=skip, limit=limit)


@router.get("/header-banner", response_model=list[schemas.HeaderBanner], include_in_schema=False)
def list_header_banner_no_slash(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return list_header_banner(db=db, skip=skip, limit=limit)


# ✅ Create header banner
@router.post("/header-banner/", response_model=schemas.HeaderBanner)
async def create_header_banner(
    title: Annotated[Any, Form()] = None,
    subtitle: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        # Convert is_active string to boolean
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        
        image_url = None
        if image is not None:
             # Ensure image is not a list (if it is, take first)
            if isinstance(image, list):
                image = image[0] if image else None
            
            if image and getattr(image, 'filename', None):
                # Generate unique filename
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"banner_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                # Save file
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving header banner image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                # Create URL path
                image_url = f"/uploads/cms/{unique_filename}"
        
        obj = schemas.HeaderBannerCreate(
            title=title,
            subtitle=subtitle,
            is_active=is_active_bool,
            image_url=image_url
        )
        return crud.create(db, models.HeaderBanner, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to create header banner: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to create header banner: {str(e)}")


# ✅ Update header banner
@router.put("/header-banner/{item_id}", response_model=schemas.HeaderBanner)
async def update_header_banner(
    item_id: int,
    title: Annotated[Any, Form()] = None,
    subtitle: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        # Convert is_active string to boolean
        if is_active is not None:
             is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        else:
             is_active_bool = True
        
        image_url = None
        if image is not None:
            # Handle possible list
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"banner_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving updated banner image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")
                
                image_url = f"/uploads/cms/{unique_filename}"

        # If no new image provided, keep existing image_url
        if image_url is None:
            existing = crud.get_one(db, models.HeaderBanner, item_id)
            if existing:
                image_url = existing.image_url

        obj = schemas.HeaderBannerUpdate(
            title=title,
            subtitle=subtitle,
            is_active=is_active_bool,
            image_url=image_url
        )
        return crud.update(db, models.HeaderBanner, item_id, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to update header banner: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to update header banner: {str(e)}")


# ✅ Delete header banner
@router.delete("/header-banner/{item_id}")
def delete_header_banner(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.HeaderBanner, item_id)

# ---------- Check Availability ----------
@router.get("/check-availability/", response_model=list[schemas.CheckAvailability])
def list_check_availability(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.CheckAvailability, skip=skip, limit=limit)


@router.get(
    "/check-availability",
    response_model=list[schemas.CheckAvailability],
    include_in_schema=False,
)
def list_check_availability_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_check_availability(db=db, skip=skip, limit=limit)


@router.post("/check-availability/", response_model=schemas.CheckAvailability)
def create_check_availability(obj: schemas.CheckAvailabilityCreate, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.create(db, models.CheckAvailability, obj)


@router.put("/check-availability/{item_id}", response_model=schemas.CheckAvailability)
def update_check_availability(item_id: int, obj: schemas.CheckAvailabilityCreate, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.update(db, models.CheckAvailability, item_id, obj)


@router.delete("/check-availability/{item_id}")
def delete_check_availability(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.CheckAvailability, item_id)


# ---------- Gallery ----------
@router.get("/gallery/", response_model=list[schemas.Gallery])
def list_gallery(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.Gallery, skip=skip, limit=limit)


@router.get("/gallery", response_model=list[schemas.Gallery], include_in_schema=False)
def list_gallery_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_gallery(db=db, skip=skip, limit=limit)


@router.post("/gallery/", response_model=schemas.Gallery)
async def create_gallery(
    caption: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        
        image_url = None
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"gallery_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving gallery image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.LANCZOS)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60, optimize=True)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"
        
        obj = schemas.GalleryCreate(
            caption=caption,
            is_active=is_active_bool,
            image_url=image_url
        )
        return crud.create(db, models.Gallery, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to create gallery image: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to create gallery image: {str(e)}")


@router.put("/gallery/{item_id}", response_model=schemas.Gallery)
async def update_gallery(
    item_id: int,
    caption: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        
        image_url = None
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"gallery_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving updated gallery image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.LANCZOS)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60, optimize=True)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"

        # If no new image provided, keep existing image_url
        if image_url is None:
            existing = crud.get_one(db, models.Gallery, item_id)
            if existing:
                image_url = existing.image_url

        obj = schemas.GalleryCreate(
            caption=caption,
            is_active=is_active_bool,
            image_url=image_url
        )
        return crud.update(db, models.Gallery, item_id, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to update gallery image: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to update gallery image: {str(e)}")

@router.delete("/gallery/{item_id}")
def delete_gallery(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.Gallery, item_id)


# ---------- Reviews ----------
@router.get("/reviews/", response_model=list[schemas.Review])
def list_reviews(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.Review, skip=skip, limit=limit)


@router.get("/reviews", response_model=list[schemas.Review], include_in_schema=False)
def list_reviews_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_reviews(db=db, skip=skip, limit=limit)


@router.post("/reviews/", response_model=schemas.Review)
def create_review(obj: schemas.ReviewCreate, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    try:
        # Ensure rating is an integer
        if isinstance(obj.rating, str):
            obj.rating = int(obj.rating)
        return crud.create(db, models.Review, obj)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to create review: {str(e)}")


@router.put("/reviews/{item_id}", response_model=schemas.Review)
def update_review(item_id: int, obj: schemas.ReviewCreate, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    try:
        # Ensure rating is an integer
        if isinstance(obj.rating, str):
            obj.rating = int(obj.rating)
        return crud.update(db, models.Review, item_id, obj)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to update review: {str(e)}")


@router.delete("/reviews/{item_id}")
def delete_review(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.Review, item_id)


# ---------- Resort Info ----------
@router.get("/resort-info/", response_model=list[schemas.ResortInfo])
def list_resort_info(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.ResortInfo, skip=skip, limit=limit)


@router.get(
    "/resort-info", response_model=list[schemas.ResortInfo], include_in_schema=False
)
def list_resort_info_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_resort_info(db=db, skip=skip, limit=limit)


@router.post("/resort-info/", response_model=schemas.ResortInfo)
def create_resort_info(
    obj: schemas.ResortInfoCreate,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    return crud.create(db, models.ResortInfo, obj)


@router.put("/resort-info/{item_id}", response_model=schemas.ResortInfo)
def update_resort_info(
    item_id: int,
    obj: schemas.ResortInfoCreate,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    return crud.update(db, models.ResortInfo, item_id, obj)


@router.delete("/resort-info/{item_id}")
def delete_resort_info(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.ResortInfo, item_id)


# ---------- Signature Experiences ----------
@router.get("/signature-experiences/", response_model=list[schemas.SignatureExperience])
def list_signature_experiences(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.SignatureExperience, skip=skip, limit=limit)


@router.get(
    "/signature-experiences",
    response_model=list[schemas.SignatureExperience],
    include_in_schema=False,
)
def list_signature_experiences_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_signature_experiences(db=db, skip=skip, limit=limit)


@router.post("/signature-experiences/", response_model=schemas.SignatureExperience)
async def create_signature_experience(
    title: Annotated[Any, Form()] = None,
    description: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        image_url = None
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"sigexp_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving signature experience image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"

        obj = schemas.SignatureExperienceCreate(
            title=title,
            description=description,
            is_active=is_active_bool,
            image_url=image_url
        )
        return crud.create(db, models.SignatureExperience, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to create signature experience: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to create signature experience: {str(e)}")


@router.put("/signature-experiences/{item_id}", response_model=schemas.SignatureExperience)
async def update_signature_experience(
    item_id: int,
    title: Annotated[Any, Form()] = None,
    description: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        update_data = {
            "title": title,
            "description": description,
            "is_active": is_active_bool,
        }
        
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"sigexp_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving updated signature experience image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"
                update_data["image_url"] = image_url

        # If no new image provided, keep existing image_url
        if "image_url" not in update_data:
            existing = crud.get_one(db, models.SignatureExperience, item_id)
            if existing:
                update_data["image_url"] = existing.image_url

        obj = schemas.SignatureExperienceUpdate(**update_data)
        return crud.update(db, models.SignatureExperience, item_id, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to update signature experience: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to update signature experience: {str(e)}")


@router.delete("/signature-experiences/{item_id}")
def delete_signature_experience(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.SignatureExperience, item_id)


# ---------- Plan Your Wedding ----------
@router.get("/plan-weddings/", response_model=list[schemas.PlanWedding])
def list_plan_weddings(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.PlanWedding, skip=skip, limit=limit)


@router.get(
    "/plan-weddings",
    response_model=list[schemas.PlanWedding],
    include_in_schema=False,
)
def list_plan_weddings_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_plan_weddings(db=db, skip=skip, limit=limit)


@router.post("/plan-weddings/", response_model=schemas.PlanWedding)
async def create_plan_wedding(
    title: Annotated[Any, Form()] = None,
    description: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        image_url = None
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"wedding_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving wedding plan image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"

        obj = schemas.PlanWeddingCreate(
            title=title,
            description=description,
            is_active=is_active_bool,
            image_url=image_url
        )
        return crud.create(db, models.PlanWedding, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to create plan wedding: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to create plan wedding: {str(e)}")


@router.put("/plan-weddings/{item_id}", response_model=schemas.PlanWedding)
async def update_plan_wedding(
    item_id: int,
    title: Annotated[Any, Form()] = None,
    description: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        update_data = {
            "title": title,
            "description": description,
            "is_active": is_active_bool,
        }
        
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"wedding_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving updated wedding plan image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"
                update_data["image_url"] = image_url
        else:
            # If no new image provided, keep existing image_url
            existing = crud.get_one(db, models.PlanWedding, item_id)
            if existing:
                update_data["image_url"] = existing.image_url

        obj = schemas.PlanWeddingUpdate(**update_data)
        return crud.update(db, models.PlanWedding, item_id, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to update plan wedding: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to update plan wedding: {str(e)}")
        print(f"ERROR: {error_detail}")
        raise HTTPException(status_code=500, detail=f"Failed to update plan wedding: {str(e)}")


@router.delete("/plan-weddings/{item_id}")
def delete_plan_wedding(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.PlanWedding, item_id)


# ---------- Nearby Attractions ----------
@router.get("/nearby-attractions/", response_model=list[schemas.NearbyAttraction])
def list_nearby_attractions(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    try:
        # Verify model is available
        if not hasattr(models, 'NearbyAttraction'):
            print("ERROR: NearbyAttraction model not found in models module")
            return []
        
        # Try to query the table
        result = crud.get_all(db, models.NearbyAttraction, skip=skip, limit=limit)
        # Ensure we return a list
        if result is None:
            return []
        return result
    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        import traceback
        error_detail = f"Failed to fetch nearby attractions: {str(e)}\n{traceback.format_exc()}"
        print(f"ERROR: {error_detail}")
        # Log to stderr as well for better visibility
        import sys
        sys.stderr.write(f"ERROR in nearby-attractions: {error_detail}\n")
        # For any error, return empty list to prevent frontend breakage
        # This allows the frontend to work even if there's a database issue
        error_str = str(e).lower()
        if "does not exist" in error_str or "relation" in error_str or "no such table" in error_str:
            print("Table may not exist yet, returning empty list")
        else:
            print(f"Unexpected error in nearby-attractions endpoint, returning empty list: {str(e)}")
        return []


@router.get(
    "/nearby-attractions",
    response_model=list[schemas.NearbyAttraction],
    include_in_schema=False,
)
def list_nearby_attractions_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_nearby_attractions(db=db, skip=skip, limit=limit)


@router.post("/nearby-attractions/", response_model=schemas.NearbyAttraction)
async def create_nearby_attraction(
    title: Annotated[Any, Form()] = None,
    description: Annotated[Any, Form()] = None,
    map_link: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        image_url = None
        if image is not None:
             # Ensure image is not a list
            if isinstance(image, list):
                image = image[0] if image else None
            
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"attraction_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving attraction image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"
        
        obj = schemas.NearbyAttractionCreate(
            title=title,
            description=description,
            is_active=is_active_bool,
            image_url=image_url,
            map_link=map_link.strip() if map_link else None,
        )
        return crud.create(db, models.NearbyAttraction, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to create nearby attraction: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to create nearby attraction: {str(e)}")


@router.put("/nearby-attractions/{item_id}", response_model=schemas.NearbyAttraction)
async def update_nearby_attraction(
    item_id: int,
    title: Annotated[Any, Form()] = None,
    description: Annotated[Any, Form()] = None,
    map_link: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        update_data = {
            "title": title,
            "description": description,
            "is_active": is_active_bool,
        }
        if map_link is not None:
            update_data["map_link"] = map_link.strip() or None
        
        if image is not None:
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"attraction_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving updated attraction image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"
                update_data["image_url"] = image_url

        # If no new image provided, keep existing image_url
        if "image_url" not in update_data:
            existing = crud.get_one(db, models.NearbyAttraction, item_id)
            if existing:
                update_data["image_url"] = existing.image_url

        obj = schemas.NearbyAttractionUpdate(**update_data)
        return crud.update(db, models.NearbyAttraction, item_id, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to update nearby attraction: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to update nearby attraction: {str(e)}")


@router.delete("/nearby-attractions/{item_id}")
def delete_nearby_attraction(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.NearbyAttraction, item_id)


@router.get("/nearby-attraction-banners/", response_model=list[schemas.NearbyAttractionBanner])
def list_nearby_attraction_banners(db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20):
    return crud.get_all(db, models.NearbyAttractionBanner, skip=skip, limit=limit)


@router.get(
    "/nearby-attraction-banners",
    response_model=list[schemas.NearbyAttractionBanner],
    include_in_schema=False,
)
def list_nearby_attraction_banners_no_slash(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_nearby_attraction_banners(db=db, skip=skip, limit=limit)


@router.get(
    "/nearby-attraction-banner",
    response_model=list[schemas.NearbyAttractionBanner],
    include_in_schema=False,
)
def list_nearby_attraction_banner_singular(
    db: Annotated[Any, Depends(get_db)] = None, skip: int = 0, limit: int = 20
):
    return list_nearby_attraction_banners(db=db, skip=skip, limit=limit)


@router.post("/nearby-attraction-banners/", response_model=schemas.NearbyAttractionBanner)
async def create_nearby_attraction_banner(
    title: Annotated[Any, Form()] = None,
    subtitle: Annotated[Any, Form()] = None,
    map_link: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        image_url = None
        if image is not None:
             # Ensure image is not a list
            if isinstance(image, list):
                image = image[0] if image else None
            
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"nearby_banner_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving nearby banner image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"

        obj = schemas.NearbyAttractionBannerCreate(
            title=title,
            subtitle=subtitle,
            image_url=image_url,
            is_active=is_active_bool,
            map_link=map_link.strip() if map_link else None,
        )
        return crud.create(db, models.NearbyAttractionBanner, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to create nearby attraction banner: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to create nearby attraction banner: {str(e)}")



@router.put("/nearby-attraction-banners/{item_id}", response_model=schemas.NearbyAttractionBanner)
async def update_nearby_attraction_banner(
    item_id: int,
    title: Annotated[Any, Form()] = None,
    subtitle: Annotated[Any, Form()] = None,
    map_link: Annotated[Any, Form()] = None,
    is_active: Annotated[Any, Form()] = "true",
    image: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    try:
        is_active_bool = str(is_active).lower() in ("true", "1", "yes", "on")
        update_data = {
            "title": title,
            "subtitle": subtitle,
            "is_active": is_active_bool,
            "map_link": map_link.strip() if map_link else None,
        }
 
        if image is not None:
             # Ensure image is not a list
            if isinstance(image, list):
                image = image[0] if image else None
                
            if image and getattr(image, 'filename', None):
                file_ext = image.filename.split('.')[-1] if '.' in image.filename else 'jpg'
                unique_filename = f"nearby_banner_{uuid.uuid4().hex}.{file_ext}"
                file_path = os.path.join(UPLOAD_DIR, unique_filename)
                
                try:
                    contents = await image.read()
                    with open(file_path, "wb") as buffer:
                        buffer.write(contents)
                except Exception as file_err:
                    print(f"Error saving updated nearby banner image: {file_err}")
                    raise HTTPException(status_code=500, detail="Failed to save image file")
                
                # Generate and Save Thumbnail
                try:
                    thumb_filename = f"{os.path.splitext(unique_filename)[0]}_thumb.jpg"
                    thumb_path = os.path.join(UPLOAD_DIR, thumb_filename)
                    with Image.open(io.BytesIO(contents)) as img_pil:
                        img_pil.thumbnail((200, 200), Image.Resampling.BICUBIC)
                        if img_pil.mode in ("RGBA", "P"):
                            img_pil = img_pil.convert("RGB")
                        img_pil.save(thumb_path, "JPEG", quality=60)
                except Exception as thumb_error:
                    print(f"Warning: Failed to generate thumbnail for {unique_filename}: {thumb_error}")

                image_url = f"/uploads/cms/{unique_filename}"
                update_data["image_url"] = image_url
        else:
            existing = crud.get_one(db, models.NearbyAttractionBanner, item_id)
            if existing:
                update_data["image_url"] = existing.image_url
 
        obj = schemas.NearbyAttractionBannerUpdate(**update_data)
        return crud.update(db, models.NearbyAttractionBanner, item_id, obj)
    except HTTPException: raise
    except Exception as e:
        import traceback
        print(f"ERROR: Failed to update nearby attraction banner: {str(e)}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Failed to update nearby attraction banner: {str(e)}")



@router.delete("/nearby-attraction-banners/{item_id}")
def delete_nearby_attraction_banner(item_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    return crud.delete(db, models.NearbyAttractionBanner, item_id)
