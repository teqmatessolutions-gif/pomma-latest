from fastapi import APIRouter, Depends, HTTPException, Body, UploadFile, File
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import or_, and_, desc, cast, Date
from typing import List, Optional, Annotated, Any
from datetime import date, datetime, time, timedelta
import random
import string
import os
import shutil

# Assume your utility and model imports are set up correctly
from app.utils.auth import get_db, get_current_user
from app.models.room import Room
from app.models.booking import Booking, BookingRoom
from app.models.Package import Package, PackageBooking, PackageBookingRoom
from app.models.user import User
from app.models.foodorder import FoodOrder, FoodOrderItem
from app.models.service import AssignedService, Service, ServiceStatus
from app.models.checkout import Checkout
import app.schemas.checkout as schemas
from app.schemas.checkout import BillSummary, BillBreakdown, CheckoutFull, CheckoutSuccess, CheckoutRequest

router = APIRouter(prefix="/bill", tags=["checkout"])

# IMPORTANT: To support this new logic, you must update your BillSummary schema.
# In `app/schemas/checkout.py`, please change the `room_number: str` field to:
# room_numbers: List[str]


# Helper function to calculate charges from checkout totals
def calculate_charges_breakdown(checkout: Checkout) -> BillBreakdown:
    # Reconstruct charges breakdown based on stored totals
    charges = BillBreakdown()
    charges.room_charges = checkout.room_total
    charges.food_charges = checkout.food_total
    charges.service_charges = checkout.service_total
    charges.package_charges = checkout.package_total
    
    # Re-calculate GST components
    # Food & Service are always 5%
    if charges.food_charges > 0:
        charges.food_gst = charges.food_charges * 0.05
        charges.food_cgst = charges.food_gst / 2
        charges.food_sgst = charges.food_gst / 2
        
    if charges.service_charges > 0:
        charges.service_gst = charges.service_charges * 0.05
        charges.service_cgst = charges.service_gst / 2
        charges.service_sgst = charges.service_gst / 2
        
    # Room/Package GST is the remainder of the tax_amount
    calculated_other_tax = (charges.food_gst or 0) + (charges.service_gst or 0)
    remaining_tax = max(0, (checkout.tax_amount or 0) - calculated_other_tax)
    
    if charges.package_charges > 0:
        charges.package_gst = remaining_tax
        charges.package_cgst = remaining_tax / 2
        charges.package_sgst = remaining_tax / 2
    elif charges.room_charges > 0:
        charges.room_gst = remaining_tax
        charges.room_cgst = remaining_tax / 2
        charges.room_sgst = remaining_tax / 2
        
    charges.total_gst = checkout.tax_amount
    charges.cgst = charges.total_gst / 2
    charges.sgst = charges.total_gst / 2
    charges.total_due = (charges.room_charges or 0) + (charges.food_charges or 0) + (charges.service_charges or 0) + (charges.package_charges or 0)
    
    return charges

@router.get("/checkouts", response_model=List[CheckoutFull])
def get_all_checkouts(
    db: Annotated[Any, Depends(get_db)] = None, 
    current_user: Annotated[Any, Depends(get_current_user)] = None, 
    skip: int = 0, 
    limit: int = 20,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    # Defensive: Handle potential automatic camelCase conversion by frontend/axios interceptors
    fromDate: Optional[str] = None,
    toDate: Optional[str] = None
):
    """Retrieves a list of checkouts, optionally filtered by date."""
    query = db.query(Checkout)

    # Debug logging
    print(f"DEBUG Params: s={start_date}, e={end_date}, fd={from_date}, td={to_date}, fD={fromDate}, tD={toDate}")

    # Use explicit start_date/end_date if provided, else fallback to from_date/to_date or camelCase variants
    final_start = start_date or from_date or fromDate
    final_end = end_date or to_date or toDate

    try:
        if final_start:
            # Handle YYYY-MM-DD
            if len(final_start) == 10 and "-" in final_start:
                dt_start = datetime.strptime(final_start, "%Y-%m-%d")
                # Start of day
                dt_start = dt_start.replace(hour=0, minute=0, second=0, microsecond=0)
                query = query.filter(Checkout.checkout_date >= dt_start)
                print(f"DEBUG: Applied Start Filter (DT): >= {dt_start}")
            # Handle ISO string (e.g. from frontend date picker sometimes)
            elif "T" in final_start:
                # Basic ISO parsing
                query = query.filter(Checkout.checkout_date >= final_start)
                print(f"DEBUG: Applied Start Filter (ISO): >= {final_start}")
            else:
                # Fallback string
                query = query.filter(Checkout.checkout_date >= final_start)
            
        if final_end:
            if len(final_end) == 10 and "-" in final_end:
                dt_end = datetime.strptime(final_end, "%Y-%m-%d")
                # End of day
                query = query.filter(Checkout.checkout_date <= dt_end)
                print(f"DEBUG: Applied End Filter (DT): <= {dt_end}")
            elif "T" in final_end:
                query = query.filter(Checkout.checkout_date <= final_end)
                print(f"DEBUG: Applied End Filter (ISO): <= {final_end}")
            else:
                query = query.filter(Checkout.checkout_date <= final_end)

    except Exception as e:
        print(f"ERROR parsing dates: {e}")
        # Fallback to string comparison
        if final_start: query = query.filter(Checkout.checkout_date >= final_start)
        if final_end: query = query.filter(Checkout.checkout_date <= final_end)

    checkouts = query.order_by(Checkout.id.desc()).offset(skip).limit(limit).all()
    print(f"DEBUG: Found {len(checkouts)} records after filtering.")
    
    # Enrich with calculated charges
    result = []
    for c in checkouts:
        c_full = CheckoutFull.from_orm(c)
        c_full.charges = calculate_charges_breakdown(c)
        result.append(c_full)
        
    return result

@router.get("/checkouts/{checkout_id}/details")
def get_checkout_details(checkout_id: int, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    """Get detailed checkout information including food orders and services."""
    checkout = db.query(Checkout).filter(Checkout.id == checkout_id).first()
    if not checkout:
        raise HTTPException(status_code=404, detail="Checkout not found")
    
    # Get room numbers from booking
    room_numbers = []
    booking_details = None
    
    if checkout.booking_id:
        booking = db.query(Booking).options(
            joinedload(Booking.booking_rooms).joinedload(BookingRoom.room)
        ).filter(Booking.id == checkout.booking_id).first()
        if booking:
            room_numbers = [br.room.number for br in booking.booking_rooms if br.room]
            booking_details = {
                "check_in": str(booking.check_in),
                "check_out": str(booking.check_out),
                "adults": booking.adults,
                "children": booking.children,
                "status": booking.status
            }
    elif checkout.package_booking_id:
        package_booking = db.query(PackageBooking).options(
            joinedload(PackageBooking.rooms).joinedload(PackageBookingRoom.room)
        ).filter(PackageBooking.id == checkout.package_booking_id).first()
        if package_booking:
            room_numbers = [pbr.room.number for pbr in package_booking.rooms if pbr.room]
            booking_details = {
                "check_in": str(package_booking.check_in),
                "check_out": str(package_booking.check_out),
                "adults": package_booking.adults,
                "children": package_booking.children,
                "status": package_booking.status,
                "package_name": package_booking.package.title if package_booking.package else None
            }
    
    # Link orphaned records (self-healing)
    # If we find records for this room/date that are 'billed' but have no booking ID, claim them now.
    room_ids = []
    rooms = []
    if room_numbers:
        rooms = db.query(Room).filter(Room.number.in_(room_numbers)).all()
        room_ids = [r.id for r in rooms]

    if room_ids:
        # Use 12:00 PM (noon) as the cutoff for auto-linking orphans on turnover days
        # This prevents claiming items from a guest who checked out in the morning,
        # or items from a guest who checks in later that afternoon (if looking at previous booking).
        orphan_start = None
        orphan_end = None
        
        if checkout.booking:
            orphan_start = datetime.combine(checkout.booking.check_in, time(12, 0, 0))
            orphan_end = datetime.combine(checkout.booking.check_out, time(12, 0, 0))
        elif checkout.package_booking:
            orphan_start = datetime.combine(checkout.package_booking.check_in, time(12, 0, 0))
            orphan_end = datetime.combine(checkout.package_booking.check_out, time(12, 0, 0))
        
        if orphan_start and orphan_end:
            # 1. Link Food Orders
            orphan_orders_query = db.query(FoodOrder).filter(
                FoodOrder.room_id.in_(room_ids),
                FoodOrder.booking_id.is_(None),
                FoodOrder.package_booking_id.is_(None),
                FoodOrder.billing_status == 'billed',
                FoodOrder.created_at >= orphan_start,
                FoodOrder.created_at <= orphan_end
            )
            orphan_orders = orphan_orders_query.all()
            if orphan_orders:
                for order in orphan_orders:
                    if checkout.booking_id:
                        order.booking_id = checkout.booking_id
                    elif checkout.package_booking_id:
                        order.package_booking_id = checkout.package_booking_id
                db.commit()

            # 2. Link Assigned Services
            orphan_services_query = db.query(AssignedService).filter(
                AssignedService.room_id.in_(room_ids),
                AssignedService.booking_id.is_(None),
                AssignedService.package_booking_id.is_(None),
                AssignedService.billing_status == 'billed',
                AssignedService.assigned_at >= orphan_start,
                AssignedService.assigned_at <= orphan_end
            )
            orphan_services = orphan_services_query.all()
            if orphan_services:
                for service in orphan_services:
                    if checkout.booking_id:
                        service.booking_id = checkout.booking_id
                    elif checkout.package_booking_id:
                        service.package_booking_id = checkout.package_booking_id
                db.commit()

    # Get food orders for these rooms (Strict ID Filter)
    food_orders = []
    
    # Calculate start date for filtering
    start_date = None
    if checkout.booking:
        start_date = datetime.combine(checkout.booking.check_in, datetime.min.time())
    elif checkout.package_booking:
        start_date = datetime.combine(checkout.package_booking.check_in, datetime.min.time())

    query = db.query(FoodOrder).options(
        joinedload(FoodOrder.items).joinedload(FoodOrderItem.food_item)
    )

    conditions = []
    if checkout.booking_id:
        conditions.append(FoodOrder.booking_id == checkout.booking_id)
    elif checkout.package_booking_id:
        conditions.append(FoodOrder.package_booking_id == checkout.package_booking_id)
    else:
        # Fallback for legacy data without IDs
        conditions.append(FoodOrder.room_id.in_(room_ids)) 

    # Apply date filter if available to exclude stale data
    if start_date:
        conditions.append(FoodOrder.created_at >= start_date)

    query = query.filter(and_(*conditions))
    
    # Helper to ensure UTC Z suffix
    def format_utc(dt):
        if not dt:
            return None
        # Assume stored as UTC naive. Return isoformat with Z.
        return dt.isoformat() + "Z"

    # Exclude cancelled orders from history view
    query = query.filter(FoodOrder.status != 'cancelled')
    
    orders = query.all()
    for order in orders:
        food_orders.append({
            "id": order.id,
            "room_number": next((r.number for r in rooms if r.id == order.room_id), None),
            "amount": order.amount,
            "status": order.status,
            "created_at": format_utc(order.created_at),
            "items": [
                {
                    "item_name": item.food_item.name if item.food_item else "Unknown",
                    "quantity": item.quantity,
                    "price": item.food_item.price if item.food_item else 0,
                    "total": item.quantity * (item.food_item.price if item.food_item else 0)
                }
                for item in order.items
            ]
    })
    
    # Get services for these rooms (Strict ID Filter)
    services = []
    query = db.query(AssignedService).options(
        joinedload(AssignedService.service)
    )

    conditions = []
    if checkout.booking_id:
            conditions.append(AssignedService.booking_id == checkout.booking_id)
    elif checkout.package_booking_id:
            conditions.append(AssignedService.package_booking_id == checkout.package_booking_id)
    else:
         conditions.append(AssignedService.room_id.in_(room_ids))

    # Apply date filter if available to exclude stale data
    if start_date:
        conditions.append(AssignedService.assigned_at >= start_date)

    query = query.filter(and_(*conditions))

    # Exclude cancelled services from history view
    query = query.filter(AssignedService.status != ServiceStatus.cancelled)

    assigned_services = query.all()
    for ass in assigned_services:
        services.append({
            "id": ass.id,
            "room_number": next((r.number for r in rooms if r.id == ass.room_id), None),
            "service_name": ass.service.name if ass.service else "Unknown",
            "charges": ass.service.charges if ass.service else 0,
            "status": ass.status,
            "created_at": format_utc(ass.assigned_at),
        })
    
    # Fallback for guest name if missing on checkout record
    guest_name = checkout.guest_name
    if not guest_name:
        if booking_details and checkout.booking_id:
             booking = db.query(Booking).filter(Booking.id == checkout.booking_id).first()
             if booking: guest_name = booking.guest_name
        elif booking_details and checkout.package_booking_id:
             pkg_booking = db.query(PackageBooking).filter(PackageBooking.id == checkout.package_booking_id).first()
             if pkg_booking: guest_name = pkg_booking.guest_name

    # Reconstruct charges breakdown for frontend compatibility
    charges = BillBreakdown()
    charges.room_charges = checkout.room_total
    charges.food_charges = checkout.food_total
    charges.service_charges = checkout.service_total
    charges.package_charges = checkout.package_total
    
    # Re-calculate GST components (Estimates based on current logic as specific GST components aren't stored)
    # Food & Service are always 5%
    if charges.food_charges > 0:
        charges.food_gst = charges.food_charges * 0.05
        charges.food_cgst = charges.food_gst / 2
        charges.food_sgst = charges.food_gst / 2
        
    if charges.service_charges > 0:
        charges.service_gst = charges.service_charges * 0.05
        charges.service_cgst = charges.service_gst / 2
        charges.service_sgst = charges.service_gst / 2
        
    # Room/Package GST is the remainder of the tax_amount
    # This ensures the total tax matches the stored record exactly
    calculated_other_tax = (charges.food_gst or 0) + (charges.service_gst or 0)
    remaining_tax = max(0, (checkout.tax_amount or 0) - calculated_other_tax)
    
    if charges.package_charges > 0:
        charges.package_gst = remaining_tax
        charges.package_cgst = remaining_tax / 2
        charges.package_sgst = remaining_tax / 2
    elif charges.room_charges > 0:
        charges.room_gst = remaining_tax
        charges.room_cgst = remaining_tax / 2
        charges.room_sgst = remaining_tax / 2
        
    charges.total_gst = checkout.tax_amount
    charges.total_due = (charges.room_charges or 0) + (charges.food_charges or 0) + (charges.service_charges or 0) + (charges.package_charges or 0)

    # Flatten food items for display
    # The frontend expects a flat list of items in the modal
    flat_food_items = []
    for order in food_orders:
         for item in order["items"]:
              existing = next((x for x in flat_food_items if x.item_name == item["item_name"]), None)
              if existing:
                   existing.quantity += item["quantity"]
                   existing.amount += item["total"]
              else:
                   flat_food_items.append(schemas.FoodOrderItem(
                        item_name=item["item_name"],
                        quantity=item["quantity"],
                        amount=item["total"]
                   ))
    charges.food_items = flat_food_items

    # Flatten service items
    flat_service_items = []
    for service in services:
         flat_service_items.append(schemas.ServiceItem(
              service_name=service["service_name"],
              charges=service["charges"]
         ))
    charges.service_items = flat_service_items

    return {
        "id": checkout.id,
        "booking_id": checkout.booking_id,
        "package_booking_id": checkout.package_booking_id,
        "room_total": checkout.room_total,
        "food_total": checkout.food_total,
        "service_total": checkout.service_total,
        "package_total": checkout.package_total,
        "tax_amount": checkout.tax_amount,
        "discount_amount": checkout.discount_amount,
        "grand_total": checkout.grand_total,
        "payment_method": checkout.payment_method,
        "payment_status": checkout.payment_status,
        "created_at": format_utc(checkout.created_at),
        "checkout_date": format_utc(checkout.checkout_date),
        "guest_name": guest_name,
        "room_number": checkout.room_number,
        "room_numbers": room_numbers,
        "food_orders": food_orders,
        "services": services,
        "booking_details": booking_details,
        "charges": charges
    }

@router.get("/active-rooms", response_model=List[dict])
def get_active_rooms(db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None, skip: int = 0, limit: int = 20):
    """
    Returns a list of active rooms available for checkout with two options:
    1. Individual rooms (for single room checkout)
    2. Grouped bookings (for multiple room checkout together)
    Used to populate the checkout dropdown on the frontend.
    """
    try:
        # Fetch active bookings and package bookings with their rooms preloaded
        # Only include 'checked-in' status (both hyphen and underscore formats)
        # Exclude 'booked' status - only show rooms that are already checked-in
        active_bookings = db.query(Booking).options(
            joinedload(Booking.booking_rooms).joinedload(BookingRoom.room)
        ).filter(Booking.status.in_(['checked-in', 'checked_in'])).all()
        
        active_package_bookings = db.query(PackageBooking).options(
            joinedload(PackageBooking.rooms).joinedload(PackageBookingRoom.room)
        ).filter(PackageBooking.status.in_(['checked-in', 'checked_in'])).all()
        
        result = []
        
        # Helper function to safely get room number
        def get_room_number(link):
            """Safely extract room number from booking room link"""
            try:
                if not link:
                    return None
                if not link.room:
                    return None
                room_num = link.room.number
                if room_num is None or (isinstance(room_num, str) and room_num.strip() == ""):
                    return None
                return str(room_num).strip()
            except (AttributeError, Exception):
                return None
        
        # Process regular bookings
        for booking in active_bookings:
            # Extract room numbers with proper null checks using helper function
            room_numbers = sorted([
                room_num for link in booking.booking_rooms 
                if (room_num := get_room_number(link)) is not None
            ])
            if room_numbers:
                # Add individual room options (one per room)
                for room_num in room_numbers:
                    result.append({
                        "room_number": room_num,
                        "room_numbers": [room_num],  # Single room
                        "guest_name": booking.guest_name,
                        "booking_id": booking.id,
                        "booking_type": "regular",
                        "checkout_mode": "single",
                        "display_label": f"Room {room_num} ({booking.guest_name})"
                    })
                
                # Add grouped booking option (all rooms together) - only if more than 1 room
                if len(room_numbers) > 1:
                    first_room = room_numbers[0]
                    result.append({
                        "room_number": first_room,  # Primary room for checkout API
                        "room_numbers": room_numbers,  # All rooms in this booking
                        "guest_name": booking.guest_name,
                        "booking_id": booking.id,
                        "booking_type": "regular",
                        "checkout_mode": "multiple",
                        "display_label": f"All Rooms in Booking #{booking.id}: {', '.join(room_numbers)} ({booking.guest_name})"
                    })
        
        # Process package bookings
        for pkg_booking in active_package_bookings:
            # Extract room numbers with proper null checks using helper function
            room_numbers = sorted([
                room_num for link in pkg_booking.rooms 
                if (room_num := get_room_number(link)) is not None
            ])
            if room_numbers:
                # Add individual room options (one per room)
                for room_num in room_numbers:
                    result.append({
                        "room_number": room_num,
                        "room_numbers": [room_num],  # Single room
                        "guest_name": pkg_booking.guest_name,
                        "booking_id": pkg_booking.id,
                        "booking_type": "package",
                        "checkout_mode": "single",
                        "display_label": f"Room {room_num} ({pkg_booking.guest_name})"
                    })
                
                # Add grouped booking option (all rooms together) - only if more than 1 room
                if len(room_numbers) > 1:
                    first_room = room_numbers[0]
                    result.append({
                        "room_number": first_room,  # Primary room for checkout API
                        "room_numbers": room_numbers,  # All rooms in this booking
                        "guest_name": pkg_booking.guest_name,
                        "booking_id": pkg_booking.id,
                        "booking_type": "package",
                        "checkout_mode": "multiple",
                        "display_label": f"All Rooms in Package #{pkg_booking.id}: {', '.join(room_numbers)} ({pkg_booking.guest_name})"
                    })
        
        # Sort by booking ID descending (most recent first)
        result = sorted(result, key=lambda x: x['booking_id'], reverse=True)
        return result[skip:skip+limit]
    except Exception as e:
        # Return empty list on error to prevent 500 response
        import traceback
        print(f"Error in get_active_rooms: {str(e)}")
        print(traceback.format_exc())
        return []

def _calculate_bill_for_single_room(db: Session, room_number: str):
    """
    Calculates bill for a single room only, regardless of how many rooms are in the booking.
    """
    # 1. Find the room
    room = db.query(Room).filter(Room.number == room_number).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found.")
    
    # 2. Find the active parent booking (regular or package) linked to this room
    booking, is_package = None, False
    
    booking_link = (db.query(BookingRoom)
                    .join(Booking)
                    .options(joinedload(BookingRoom.booking))
                    .filter(BookingRoom.room_id == room.id, 
                            or_(
                                Booking.status.in_(['checked-in', 'checked_in']),
                                and_(Booking.status == 'booked', Booking.check_in <= date.today())
                            ))
                    .order_by(Booking.id.desc()).first())
    
    if booking_link:
        booking = booking_link.booking
        if booking.status not in ['checked-in', 'checked_in', 'booked']:
            raise HTTPException(status_code=400, detail=f"Booking is not in a valid state for checkout. Current status: {booking.status}")
    else:
        package_link = (db.query(PackageBookingRoom)
                        .join(PackageBooking)
                        .options(joinedload(PackageBookingRoom.package_booking))
                        .filter(PackageBookingRoom.room_id == room.id, 
                                or_(
                                    PackageBooking.status.in_(['checked-in', 'checked_in']),
                                    and_(PackageBooking.status == 'booked', PackageBooking.check_in <= date.today())
                                ))
                        .order_by(PackageBooking.id.desc()).first())
        if package_link:
            booking = package_link.package_booking
            is_package = True
            if booking.status not in ['checked-in', 'checked_in', 'booked']:
                raise HTTPException(status_code=400, detail=f"Package booking is not in a valid state for checkout. Current status: {booking.status}")
    
    if not booking:
        raise HTTPException(status_code=404, detail=f"No active booking found for room {room_number}.")
    
    # 3. Calculate charges for THIS ROOM ONLY
    charges = BillBreakdown()
    
    # Calculate effective checkout date:
    # If actual checkout date (today) > booking.check_out (late checkout): use today
    # If actual checkout date (today) < booking.check_out (early checkout): use booking.check_out
    today = date.today()
    effective_checkout_date = max(today, booking.check_out)
    stay_days = max(1, (effective_checkout_date - booking.check_in).days)
    
    if is_package:
        # Check if this is a whole_property package
        package = booking.package if booking.package else None
        is_whole_property = False
        if package:
            # Check booking_type field
            booking_type = getattr(package, 'booking_type', None)
            if booking_type:
                is_whole_property = booking_type.lower() in ['whole_property', 'whole property']
            else:
                # Fallback: if no room_types specified, treat as whole_property (legacy packages)
                room_types = getattr(package, 'room_types', None)
                is_whole_property = not room_types or not room_types.strip()
        
        package_price = package.price if package else 0
        
        if is_whole_property:
            # For whole_property packages: package price is the total amount per night
            # Note: For single room checkout, we still use the full package price
            # as it's a whole property package (all rooms included)
            charges.package_charges = package_price * stay_days
            charges.room_charges = 0
        else:
            # For room_type packages: package price is per room, per night
            charges.package_charges = package_price * stay_days
            charges.room_charges = 0
    else:
        charges.package_charges = 0
        # For regular bookings: calculate room charges as days * room price
        charges.room_charges = (room.price or 0) * stay_days
    
    # Get food and service charges for THIS ROOM ONLY
    # Include food orders with billing_status "unbilled" or NULL (for orders created before billing_status was added)
    # Exclude only orders that are explicitly marked as "billed"
    unbilled_food_order_items = (db.query(FoodOrderItem)
                                 .join(FoodOrder)
                                 .options(joinedload(FoodOrderItem.food_item))
                                 .filter(FoodOrder.room_id == room.id, 
                                        or_(FoodOrder.billing_status == "unbilled", 
                                            FoodOrder.billing_status.is_(None)))
                                 .filter(FoodOrder.status != "cancelled")
                                 .all())
    
    unbilled_services = db.query(AssignedService).options(joinedload(AssignedService.service)).filter(
        AssignedService.room_id == room.id, 
        AssignedService.billing_status == "unbilled",
        AssignedService.status != ServiceStatus.cancelled
    ).all()
    
    charges.food_charges = sum(item.quantity * item.food_item.price for item in unbilled_food_order_items if item.food_item)
    charges.service_charges = sum(ass.service.charges for ass in unbilled_services)
    
    # Aggregate food items
    food_aggregation = {}
    for item in unbilled_food_order_items:
        if not item.food_item: continue
        name = item.food_item.name
        if name in food_aggregation:
            food_aggregation[name]['quantity'] += item.quantity
            food_aggregation[name]['amount'] += item.quantity * item.food_item.price
        else:
            food_aggregation[name] = {
                "item_name": name,
                "quantity": item.quantity,
                "amount": item.quantity * item.food_item.price
            }
    charges.food_items = list(food_aggregation.values())

    # Aggregate service items
    service_aggregation = {}
    for ass in unbilled_services:
        if not ass.service: continue
        name = ass.service.name
        if name in service_aggregation:
            service_aggregation[name]['charges'] += ass.service.charges
            service_aggregation[name]['quantity'] += 1
        else:
            service_aggregation[name] = {
                "service_name": name,
                "quantity": 1,
                "charges": ass.service.charges
            }
    charges.service_items = list(service_aggregation.values())
    
    # Calculate GST
    # Room charges: 5% GST if <= 7500, 18% GST if > 7500
    room_charge_amount = charges.room_charges or 0
    if room_charge_amount > 0:
        if room_charge_amount <= 7500:
            charges.room_gst = room_charge_amount * 0.05
        else:
            charges.room_gst = room_charge_amount * 0.18
        charges.room_cgst = charges.room_gst / 2
        charges.room_sgst = charges.room_gst / 2
    
    # Package charges: Same rule as room charges (5% if <= 7500, 18% if > 7500)
    package_charge_amount = charges.package_charges or 0
    if package_charge_amount > 0:
        if package_charge_amount <= 7500:
            charges.package_gst = package_charge_amount * 0.05
        else:
            charges.package_gst = package_charge_amount * 0.18
        charges.package_cgst = charges.package_gst / 2
        charges.package_sgst = charges.package_gst / 2
    
    # Food charges: 5% GST always
    food_charge_amount = charges.food_charges or 0
    if food_charge_amount > 0:
        charges.food_gst = food_charge_amount * 0.05
        charges.food_cgst = charges.food_gst / 2
        charges.food_sgst = charges.food_gst / 2

    # Service charges: 5% GST
    service_charge_amount = charges.service_charges or 0
    if service_charge_amount > 0:
        charges.service_gst = service_charge_amount * 0.05
        charges.service_cgst = charges.service_gst / 2
        charges.service_sgst = charges.service_gst / 2
    
    # Grand Total GST
    charges.total_gst = (charges.room_gst or 0) + (charges.food_gst or 0) + (charges.service_gst or 0) + (charges.package_gst or 0)
    charges.cgst = charges.total_gst / 2
    charges.sgst = charges.total_gst / 2
    
    # Total due (subtotal before GST)
    charges.total_due = sum([charges.room_charges, charges.food_charges, charges.service_charges, charges.package_charges])
    
    number_of_guests = getattr(booking, 'number_of_guests', 1)
    
    return {
        "booking": booking, "room": room, "charges": charges,
        "is_package": is_package, "stay_nights": stay_days, "number_of_guests": number_of_guests,
        "effective_checkout_date": effective_checkout_date
    }

def _calculate_bill_for_entire_booking(db: Session, room_number: str):
    """
    Core logic: Finds an entire booking from a single room number and calculates the total bill
    for all associated rooms and services.
    """
    # 1. Find the initial room to identify the parent booking
    initial_room = db.query(Room).filter(Room.number == room_number).first()
    if not initial_room:
        raise HTTPException(status_code=404, detail="Initial room not found.")

    # 2. Find the active parent booking (regular or package) linked to this room
    booking, is_package = None, False
    
    # Eagerly load the booking relationship to avoid extra queries
    # Order by descending ID to get the MOST RECENT booking for the room first.
    # Handle both 'checked-in' and 'checked_in' status formats
    booking_link = (db.query(BookingRoom)
                    .join(Booking)
                    .options(joinedload(BookingRoom.booking)) # Eager load the booking
                    .filter(BookingRoom.room_id == initial_room.id, 
                            or_(
                                Booking.status.in_(['checked-in', 'checked_in']),
                                and_(Booking.status == 'booked', Booking.check_in <= date.today())
                            ))
                    .order_by(Booking.id.desc()).first())

    if booking_link:
        booking = booking_link.booking
        # Validate booking status before proceeding
        if booking.status not in ['checked-in', 'checked_in', 'booked']:
            raise HTTPException(status_code=400, detail=f"Booking is not in a valid state for checkout. Current status: {booking.status}")
    else:
        package_link = (db.query(PackageBookingRoom)
                        .join(PackageBooking)
                        .options(joinedload(PackageBookingRoom.package_booking)) # Eager load the booking
                        .filter(PackageBookingRoom.room_id == initial_room.id, 
                                or_(
                                    PackageBooking.status.in_(['checked-in', 'checked_in']),
                                    and_(PackageBooking.status == 'booked', PackageBooking.check_in <= date.today())
                                ))
                        .order_by(PackageBooking.id.desc()).first())
        if package_link:
            booking = package_link.package_booking
            is_package = True
            # Validate booking status before proceeding
            if booking.status not in ['checked-in', 'checked_in', 'booked']:
                raise HTTPException(status_code=400, detail=f"Package booking is not in a valid state for checkout. Current status: {booking.status}")

    if not booking:
        raise HTTPException(status_code=404, detail=f"No active booking found for room {room_number}.")

    # 3. Get ALL rooms and their IDs associated with the found booking
    all_rooms = []
    if is_package:
        # For package bookings, the relationship is `booking.rooms` -> `PackageBookingRoom` -> `room`
        all_rooms = [link.room for link in booking.rooms]
    else:
        # For regular bookings, the relationship is `booking.booking_rooms` -> `BookingRoom` -> `room`
        all_rooms = [link.room for link in booking.booking_rooms]
    
    room_ids = [room.id for room in all_rooms]
    
    if not all_rooms:
         raise HTTPException(status_code=404, detail="Booking found, but no rooms are linked to it.")

    # 4. Calculate total charges across ALL rooms
    charges = BillBreakdown()
    
    # Calculate effective checkout date:
    # If actual checkout date (today) > booking.check_out (late checkout): use today
    # If actual checkout date (today) < booking.check_out (early checkout): use booking.check_out
    today = date.today()
    effective_checkout_date = max(today, booking.check_out)
    stay_days = max(1, (effective_checkout_date - booking.check_in).days)

    if is_package:
        # Check if this is a whole_property package
        package = booking.package if booking.package else None
        is_whole_property = False
        if package:
            # Check booking_type field
            booking_type = getattr(package, 'booking_type', None)
            if booking_type:
                is_whole_property = booking_type.lower() in ['whole_property', 'whole property']
            else:
                # Fallback: if no room_types specified, treat as whole_property (legacy packages)
                room_types = getattr(package, 'room_types', None)
                is_whole_property = not room_types or not room_types.strip()
        
        package_price = package.price if package else 0
        
        if is_whole_property:
            # For whole_property packages: package price is the total amount per night
            charges.package_charges = package_price * stay_days
            charges.room_charges = 0  # Room charges are included in the package price
        else:
            # For room_type packages: package price is per room, per night
            num_rooms_in_package = len(all_rooms)
            charges.package_charges = package_price * num_rooms_in_package * stay_days
            charges.room_charges = 0  # Room charges are included in the package price
    else:
        charges.package_charges = 0
        # For regular bookings: calculate room charges as number of rooms * days * room price
        charges.room_charges = sum((room.price or 0) * stay_days for room in all_rooms)
    
    # Sum up additional food and service charges from all rooms
    # We need to get the individual items from the orders to display them.
    # Include food orders with billing_status "unbilled" or NULL (for orders created before billing_status was added)
    # Exclude only orders that are explicitly marked as "billed"
    unbilled_food_order_items = (db.query(FoodOrderItem)
                                 .join(FoodOrder)
                                 .options(joinedload(FoodOrderItem.food_item))
                                 .filter(FoodOrder.room_id.in_(room_ids), 
                                        or_(FoodOrder.billing_status == "unbilled", 
                                            FoodOrder.billing_status.is_(None)))
                                 .filter(FoodOrder.status != "cancelled")
                                 .all())

    unbilled_services = db.query(AssignedService).options(joinedload(AssignedService.service)).filter(
        AssignedService.room_id.in_(room_ids), 
        AssignedService.billing_status == "unbilled",
        AssignedService.status != ServiceStatus.cancelled
    ).all()

    # Calculate total food charges from the individual items.
    charges.food_charges = sum(item.quantity * item.food_item.price for item in unbilled_food_order_items if item.food_item)
    charges.service_charges = sum(ass.service.charges for ass in unbilled_services)

    # Populate detailed item lists for the bill summary
    # Aggregate food items
    food_aggregation = {}
    for item in unbilled_food_order_items:
        if not item.food_item: continue
        name = item.food_item.name
        if name in food_aggregation:
            food_aggregation[name]['quantity'] += item.quantity
            food_aggregation[name]['amount'] += item.quantity * item.food_item.price
        else:
            food_aggregation[name] = {
                "item_name": name,
                "quantity": item.quantity,
                "amount": item.quantity * item.food_item.price
            }
    charges.food_items = list(food_aggregation.values())

    # Aggregate service items
    service_aggregation = {}
    for ass in unbilled_services:
        if not ass.service: continue
        name = ass.service.name
        if name in service_aggregation:
            service_aggregation[name]['charges'] += ass.service.charges
            service_aggregation[name]['quantity'] += 1
        else:
            service_aggregation[name] = {
                "service_name": name,
                "quantity": 1,
                "charges": ass.service.charges
            }
    charges.service_items = list(service_aggregation.values())

    # Calculate GST
    # Room charges: 5% GST if <= 7500, 18% GST if > 7500
    room_charge_amount = charges.room_charges or 0
    if room_charge_amount > 0:
        if room_charge_amount <= 7500:
            charges.room_gst = room_charge_amount * 0.05
        else:
            charges.room_gst = room_charge_amount * 0.18
        charges.room_cgst = charges.room_gst / 2
        charges.room_sgst = charges.room_gst / 2
    
    # Package charges: Same rule as room charges (5% if <= 7500, 18% if > 7500)
    package_charge_amount = charges.package_charges or 0
    if package_charge_amount > 0:
        if package_charge_amount <= 7500:
            charges.package_gst = package_charge_amount * 0.05
        else:
            charges.package_gst = package_charge_amount * 0.18
        charges.package_cgst = charges.package_gst / 2
        charges.package_sgst = charges.package_gst / 2
    
    # Food charges: 5% GST always
    food_charge_amount = charges.food_charges or 0
    if food_charge_amount > 0:
        charges.food_gst = food_charge_amount * 0.05
        charges.food_cgst = charges.food_gst / 2
        charges.food_sgst = charges.food_gst / 2

    # Service charges: 5% GST
    service_charge_amount = charges.service_charges or 0
    if service_charge_amount > 0:
        charges.service_gst = service_charge_amount * 0.05
        charges.service_cgst = charges.service_gst / 2
        charges.service_sgst = charges.service_gst / 2
    
    # Grand Total GST
    charges.total_gst = (charges.room_gst or 0) + (charges.food_gst or 0) + (charges.service_gst or 0) + (charges.package_gst or 0)
    charges.cgst = charges.total_gst / 2
    charges.sgst = charges.total_gst / 2

    # Total due (subtotal before GST)
    charges.total_due = sum([charges.room_charges, charges.food_charges, charges.service_charges, charges.package_charges])

    # Assume number_of_guests is a field on the booking model. Default to 1 if not present.
    number_of_guests = getattr(booking, 'number_of_guests', 1)

    return {
        "booking": booking, "all_rooms": all_rooms, "charges": charges, 
        "is_package": is_package, "stay_nights": stay_days, "number_of_guests": number_of_guests,
        "effective_checkout_date": effective_checkout_date
    }


@router.get("/{room_number}", response_model=BillSummary)
def get_bill_for_booking(room_number: str, checkout_mode: str = "multiple", db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    """
    Returns a bill summary for the booking associated with the given room number.
    If checkout_mode is 'single', calculates bill for that room only.
    If checkout_mode is 'multiple', calculates bill for all rooms in the booking.
    """
    if checkout_mode == "single":
        bill_data = _calculate_bill_for_single_room(db, room_number)
        effective_checkout = bill_data.get("effective_checkout_date", bill_data["booking"].check_out)
        return BillSummary(
            guest_name=bill_data["booking"].guest_name,
            room_numbers=[bill_data["room"].number],
            number_of_guests=bill_data["number_of_guests"],
            stay_nights=bill_data["stay_nights"],
            check_in=bill_data["booking"].check_in,
            check_out=effective_checkout,  # Use effective checkout date (today if late, booking.check_out if early)
            charges=bill_data["charges"]
        )
    else:
        bill_data = _calculate_bill_for_entire_booking(db, room_number)
        effective_checkout = bill_data.get("effective_checkout_date", bill_data["booking"].check_out)
        return BillSummary(
            guest_name=bill_data["booking"].guest_name,
            room_numbers=sorted([room.number for room in bill_data["all_rooms"]]),
            number_of_guests=bill_data["number_of_guests"],
            stay_nights=bill_data["stay_nights"],
            check_in=bill_data["booking"].check_in,
            check_out=effective_checkout,  # Use effective checkout date (today if late, booking.check_out if early)
            charges=bill_data["charges"]
        )


@router.post("/checkout/{room_number}", response_model=CheckoutSuccess)
def process_booking_checkout(room_number: str, request: CheckoutRequest, db: Annotated[Any, Depends(get_db)] = None, current_user: Annotated[Any, Depends(get_current_user)] = None):
    """
    Finalizes the checkout for a room or entire booking.
    If checkout_mode is 'single', only the specified room is checked out.
    If checkout_mode is 'multiple', all rooms in the booking are checked out together.
    """
    checkout_mode = request.checkout_mode or "multiple"
    
    # Ensure checkout_mode is valid
    if checkout_mode not in ["single", "multiple"]:
        checkout_mode = "multiple"  # Default to multiple if invalid
    
    if checkout_mode == "single":
        # Single room checkout
        # Calculate bill first - this will validate that there's an active booking
        bill_data = _calculate_bill_for_single_room(db, room_number)
        booking = bill_data["booking"]
        room = bill_data["room"]
        charges = bill_data["charges"]
        is_package = bill_data["is_package"]
        
        # Validate booking is in a valid state (this is the source of truth, not room status)
        if booking.status not in ['checked-in', 'checked_in', 'booked']:
            raise HTTPException(status_code=400, detail=f"Booking cannot be checked out. Current status: {booking.status}")
        
        # Check if there's already a checkout for THIS booking (to prevent double billing the same guest)
        # We NO LONGER block based on room_number + today, because a room can be checked out multiple times
        # in one day (e.g. Guest A leaves at 10am, Guest B arrives at 2pm and leaves at 8pm).
        
        existing_booking_checkout = None
        if not is_package:
             existing_booking_checkout = db.query(Checkout).filter(Checkout.booking_id == booking.id).first()
        else:
             existing_booking_checkout = db.query(Checkout).filter(Checkout.package_booking_id == booking.id).first()
             
        if existing_booking_checkout:
             raise HTTPException(
                status_code=409,
                detail=f"This booking has already been checked out (Checkout ID: {existing_booking_checkout.id}). Please refresh."
             )
        
        # Check if booking is already checked out (more reliable than room status)
        if booking.status in ['checked_out', 'checked-out']:
            raise HTTPException(
                status_code=409, 
                detail=f"Booking for room {room_number} has already been checked out. Please refresh the page to see updated status."
            )
        
        try:
            # Calculate final bill with GST
            subtotal = charges.total_due
            # Use the calculated GST from charges (already includes room, food, and package GST)
            tax_amount = charges.total_gst or 0
            discount_amount = max(0, request.discount_amount or 0)
            grand_total = max(0, subtotal + tax_amount - discount_amount)
            
            # Get effective checkout date for billing (today if late checkout, booking.check_out if early)
            effective_checkout = bill_data.get("effective_checkout_date", booking.check_out)
            # Convert date to datetime for checkout_date field
            effective_checkout_datetime = datetime.combine(effective_checkout, datetime.min.time())
            
            # Create checkout record for single room
            # For single room checkout, we need to link to booking_id/package_booking_id for display
            # However, unique constraint on booking_id prevents multiple single-room checkouts from same booking
            # Solution: Only set booking_id/package_booking_id if this is the first checkout for this booking
            # Otherwise, leave it NULL and rely on room_number for tracking
            
            # Check if there's already a checkout with this booking_id (multiple room checkout case)
            existing_booking_checkout = None
            if not is_package:
                existing_booking_checkout = db.query(Checkout).filter(Checkout.booking_id == booking.id).first()
            else:
                existing_booking_checkout = db.query(Checkout).filter(Checkout.package_booking_id == booking.id).first()
            
            # Set booking_id/package_booking_id only if no checkout exists for this booking yet
            # This ensures at least one checkout per booking shows the booking_id
            booking_id_to_set = None
            package_booking_id_to_set = None
            
            if not existing_booking_checkout:
                # First checkout for this booking - set the IDs
                booking_id_to_set = booking.id if not is_package else None
                package_booking_id_to_set = booking.id if is_package else None
            
            new_checkout = Checkout(
                booking_id=booking_id_to_set,  # Set only for first checkout per booking
                package_booking_id=package_booking_id_to_set,  # Set only for first checkout per booking
                room_total=charges.room_charges,
                food_total=charges.food_charges,
                service_total=charges.service_charges,
                package_total=charges.package_charges,
                tax_amount=tax_amount,
                discount_amount=discount_amount,
                grand_total=grand_total,
                payment_method=request.payment_method,
                payment_status="Paid",
                guest_name=booking.guest_name,
                room_number=room.number,
                checkout_date=effective_checkout_datetime  # Use effective checkout date
            )
            db.add(new_checkout)
            
            # Update only this room's related records
            # Also update the booking/package linkage to ensure they appear in the receipts/details
            update_data = {"billing_status": "billed"}
            if not is_package:
                update_data["booking_id"] = booking.id
                update_data["package_booking_id"] = None
            else:
                update_data["booking_id"] = None
                update_data["package_booking_id"] = booking.id

            db.query(FoodOrder).filter(FoodOrder.room_id == room.id, FoodOrder.billing_status == "unbilled").update(update_data)
            db.query(AssignedService).filter(AssignedService.room_id == room.id, AssignedService.billing_status == "unbilled").update(update_data)
            
            # Update room status only (don't change booking status)
            room.status = "Available"
            
            # Check if all rooms in booking are checked out, then update booking status
            if is_package:
                remaining_rooms = [link.room for link in booking.rooms if link.room.status != "Available"]
            else:
                remaining_rooms = [link.room for link in booking.booking_rooms if link.room.status != "Available"]
            
            if not remaining_rooms:
                # All rooms checked out, mark booking as checked out
                booking.status = "checked_out"
            
            db.commit()
            db.refresh(new_checkout)
            
        except Exception as e:
            db.rollback()
            error_detail = str(e)
            # Check for unique constraint violation
            if "unique constraint" in error_detail.lower() or "duplicate key" in error_detail.lower() or "23505" in error_detail:
                raise HTTPException(
                    status_code=409, 
                    detail=f"Checkout failed: A checkout record may already exist for this booking."
                )
            raise HTTPException(status_code=500, detail=f"Checkout failed due to an internal error: {error_detail}")
        
        return CheckoutSuccess(
            checkout_id=new_checkout.id,
            grand_total=new_checkout.grand_total,
            checkout_date=new_checkout.checkout_date or new_checkout.created_at
        )
    
    else:
        # Multiple room checkout (entire booking)
        bill_data = _calculate_bill_for_entire_booking(db, room_number)

        booking = bill_data["booking"]
        all_rooms = bill_data["all_rooms"]
        charges = bill_data["charges"]
        is_package = bill_data["is_package"]
        room_ids = [room.id for room in all_rooms]

        # Check if booking is already checked out
        if booking.status in ["checked_out", "checked-out"]:
            raise HTTPException(status_code=409, detail=f"This booking has already been checked out.")
        
        # Validate booking is in a valid state for checkout
        if booking.status not in ['checked-in', 'checked_in', 'booked']:
            raise HTTPException(status_code=400, detail=f"Booking cannot be checked out. Current status: {booking.status}")
        
        # Check if a checkout record already exists for this booking (unique constraint)
        existing_checkout = None
        if not is_package:
            existing_checkout = db.query(Checkout).filter(Checkout.booking_id == booking.id).first()
        else:
            existing_checkout = db.query(Checkout).filter(Checkout.package_booking_id == booking.id).first()
        
        if existing_checkout:
            raise HTTPException(status_code=409, detail=f"This booking has already been checked out. Checkout ID: {existing_checkout.id}")
        
        # Check if any rooms are already checked out
        already_checked_out_rooms = [room.number for room in all_rooms if room.status == "Available"]
        if already_checked_out_rooms:
            raise HTTPException(
                status_code=409, 
                detail=f"Some rooms in this booking are already checked out: {', '.join(already_checked_out_rooms)}. Please checkout remaining rooms individually or select rooms that are still checked in."
            )
        
        try:
            # Calculate final bill with GST
            subtotal = charges.total_due
            # Use the calculated GST from charges (already includes room, food, and package GST)
            tax_amount = charges.total_gst or 0
            # Apply discount from the request, ensuring it's not negative
            discount_amount = max(0, request.discount_amount or 0)
            grand_total = max(0, subtotal + tax_amount - discount_amount)
            
            # Get effective checkout date for billing (today if late checkout, booking.check_out if early)
            effective_checkout = bill_data.get("effective_checkout_date", booking.check_out)
            # Convert date to datetime for checkout_date field
            effective_checkout_datetime = datetime.combine(effective_checkout, datetime.min.time())

            # Create a single checkout record for the entire booking
            new_checkout = Checkout(
                booking_id=booking.id if not is_package else None,
                package_booking_id=booking.id if is_package else None,
                room_total=charges.room_charges,
                food_total=charges.food_charges,
                service_total=charges.service_charges,
                package_total=charges.package_charges,
                tax_amount=tax_amount,
                discount_amount=discount_amount,
                grand_total=grand_total,
                payment_method=request.payment_method,
                payment_status="Paid",
                guest_name=booking.guest_name,
                room_number=", ".join(sorted([room.number for room in all_rooms])),
                checkout_date=effective_checkout_datetime  # Use effective checkout date
            )
            db.add(new_checkout)

            # Atomically update all related records
            # Ensure items are linked to this booking so they show up in details
            update_data = {"billing_status": "billed"}
            if not is_package:
                update_data["booking_id"] = booking.id
                update_data["package_booking_id"] = None
            else:
                update_data["booking_id"] = None
                update_data["package_booking_id"] = booking.id

            db.query(FoodOrder).filter(FoodOrder.room_id.in_(room_ids), FoodOrder.billing_status == "unbilled").update(update_data)
            db.query(AssignedService).filter(AssignedService.room_id.in_(room_ids), AssignedService.billing_status == "unbilled").update(update_data)
            
            booking.status = "checked_out"
            db.query(Room).filter(Room.id.in_(room_ids)).update({"status": "Available"})

            db.commit()
            db.refresh(new_checkout)

        except Exception as e:
            db.rollback()
            error_detail = str(e)
            # Check for unique constraint violation (postgres error code 23505)
            if "unique constraint" in error_detail.lower() or "duplicate key" in error_detail.lower() or "23505" in error_detail:
                raise HTTPException(
                    status_code=409, 
                    detail=f"This booking has already been checked out. A checkout record already exists for this booking."
                )
            raise HTTPException(status_code=500, detail=f"Checkout failed due to an internal error: {error_detail}")

        # Return the data from the newly created checkout record
        return CheckoutSuccess(
            checkout_id=new_checkout.id,
            grand_total=new_checkout.grand_total,
            checkout_date=new_checkout.checkout_date or new_checkout.created_at
        )


@router.post("/checkout/{checkout_id}/upload-pdf")
def upload_checkout_pdf(
    checkout_id: int,
    file: Annotated[Any, File()] = None,
    db: Annotated[Any, Depends(get_db)] = None,
    current_user: Annotated[Any, Depends(get_current_user)] = None
):
    """
    Uploads a PDF invoice for a specific checkout record.
    """
    print(f"DEBUG: Handling upload for checkout_id={checkout_id}")
    # print(f"DEBUG: DB URL: {db.bind.url}") 
    checkout = db.query(Checkout).filter(Checkout.id == checkout_id).first()
    if not checkout:
        print(f"DEBUG: Checkout {checkout_id} NOT FOUND in DB.")
        raise HTTPException(status_code=404, detail="Checkout not found")
    else:
        print(f"DEBUG: Checkout {checkout_id} FOUND. Proceeding with upload.")

    # Validate file type (optional but recommended)
    if not file.content_type == "application/pdf":
        raise HTTPException(status_code=400, detail="Only PDF files are allowed.")

    # Create upload directory if it doesn't exist
    upload_dir = "uploads/invoices"
    os.makedirs(upload_dir, exist_ok=True)

    # Generate unique filename
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filename = f"invoice_{checkout_id}_{timestamp}_{file.filename}"
    file_path = os.path.join(upload_dir, filename)

    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")

    # Update checkout record with the RELATIVE URL path
    # Frontends usually expect /uploads/..., conform to that convention
    # Force forward slashes for URL compatibility
    relative_path = f"/{upload_dir}/{filename}".replace("\\", "/")
    
    checkout.pdf_url = relative_path
    db.commit()
    db.refresh(checkout)

    return {"message": "PDF uploaded successfully", "pdf_url": relative_path}
